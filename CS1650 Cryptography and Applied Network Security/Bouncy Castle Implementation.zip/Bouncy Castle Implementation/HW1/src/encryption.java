import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Random;
import java.util.Scanner;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.xml.bind.DatatypeConverter;
import org.bouncycastle.*;

public class encryption {
	
	private static KeyGenerator kg;
	private static String hashedSignature;
	
	public static void main(String[] args) throws NoSuchProviderException {
		
		Scanner read = new Scanner(System.in);
		System.out.print("Please enter a plain text: ");
		String plainText = read.nextLine();
		
		AES(plainText);
		TwoFish(plainText);
		RSA(plainText);
		System.out.println("Signature Authentication:");
		hashedSignature = SHA1(plainText);
		if (hashedSignature.equals(RSA(hashedSignature))) {
			System.out.println("Authetication Comfirmed!");
		} else {
			System.out.println("Authetication Fail!");
		}
		
		
		ArrayList<String> arrayList = stringGenerator(100);
		
		long start = System.currentTimeMillis(); 
		for(String s: arrayList) 
		{
			AES(s);
		}
		long AESSpentTime = System.currentTimeMillis() - start;
		
		start = System.currentTimeMillis(); 
		for(String s: arrayList) 
		{
			TwoFish(s);
		}
		long TwoFishSpentTime = System.currentTimeMillis() - start;
		
		start = System.currentTimeMillis(); 
		for(String s: arrayList) 
		{
			RSA(s);
		}
		long RSASpentTime = System.currentTimeMillis() - start;
		
		System.out.println("Bonus Credit");
		System.out.printf("AES: %d(ms), TwoFish: %d(ms), RSA: %d(ms) \n", (int)AESSpentTime, (int)TwoFishSpentTime, (int)RSASpentTime);
		System.out.printf("AES is %d ms faster than RSA \n", (int)RSASpentTime-(int)AESSpentTime);
		System.out.printf("Twofish is %d ms faster than RSA \n", (int)RSASpentTime-(int)TwoFishSpentTime);
		System.out.printf("Twofish is %d ms faster than AES \n", (int)AESSpentTime-(int)TwoFishSpentTime);
		
	}
	
	
	
	private static void TwoFish(String plainText) throws NoSuchProviderException {
		
		String result = null;
		try {
			
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			
			SecureRandom ra = new SecureRandom();
			KeyGenerator kg = KeyGenerator.getInstance("Twofish", "BC");
			kg.init(ra);
			SecretKey sk = kg.generateKey();
			
			Cipher cipher = Cipher.getInstance("twofish");
			cipher.init(Cipher.ENCRYPT_MODE, sk);
			
			byte[] encryption = cipher.doFinal(plainText.getBytes());
			
			cipher.init(Cipher.DECRYPT_MODE, sk);
			byte[] decryption = cipher.doFinal(encryption);
			
			System.out.println("Twofish Encryption: " + Base64.getEncoder().encodeToString(encryption));
			System.out.println("Twofish Decryption: " + new String(decryption));
			System.out.println("");
			
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private static String SHA1(String name){
		
		String result = null;
		MessageDigest msD;
		try {
			msD = MessageDigest.getInstance("SHA-1");
			msD.update(name.getBytes("UTF-8"), 0, name.length());
			result = DatatypeConverter.printHexBinary(msD.digest());
			
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	
	private static String RSA(String plainText) {
		
		String text = null;
		
		try {
			KeyPairGenerator kg2 = KeyPairGenerator.getInstance("RSA");
			kg2.initialize(1024);
			KeyPair key = kg2.genKeyPair();
			
			//System.out.println("Public Key: " + Base64.getEncoder().encodeToString(key.getPublic().getEncoded()));
			//System.out.println("Private Key: " + Base64.getEncoder().encodeToString(key.getPrivate().getEncoded()));
			
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(Cipher.ENCRYPT_MODE, key.getPublic());
			byte[] result = cipher.doFinal(plainText.getBytes());
			
			System.out.println("RSA Encryption: " + Base64.getEncoder().encodeToString(result));
			text = Base64.getEncoder().encodeToString(result);
			
			cipher.init(Cipher.DECRYPT_MODE, key.getPrivate());
			byte[] bys = cipher.doFinal(result);
			System.out.println("RSA Decryption: " + new String(bys)); 
			
			System.out.println("");
			
			text = new String(bys);
			
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println("Err: " + e.getMessage());
		}	
		
		return text;
		
	}
	
	private static void AES(String plainText) {
		
		try {
			
			// Key Production
			kg = KeyGenerator.getInstance("AES");
			kg.init(256);
			Key key = kg.generateKey();
			
			//System.out.println("Secret Key: " + Base64.getEncoder().encodeToString(key.getEncoded()));
			
			// Encryption
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] result = cipher.doFinal(plainText.getBytes("UTF-8"));
			System.out.println("AES Encryption: " + Base64.getEncoder().encodeToString(result));
		
			cipher.init(Cipher.DECRYPT_MODE, key);  
	        byte[] bys = cipher.doFinal(result);  
	        System.out.println("AES Decryption: " + new String(bys)); 
	        System.out.println("");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("Err: " + e.getMessage());
		}
		
	}
	
	private static ArrayList<String> stringGenerator(int sizeoftext) 
	{
		int ARRAY_SIZE = 100;
		
		String contain = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		ArrayList<String> stringArr = new ArrayList<String>(sizeoftext);
		for(int k = 0; k < ARRAY_SIZE; k++) 
		{
			sb.delete(0, sb.length());
			for(int i = 0; i < sizeoftext; i++)
			{
				sb.append(contain.charAt(random.nextInt(contain.length())));
			}
			stringArr.add(sb.toString());
		}
		
		return stringArr;
		
	}
}

