import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.SignedObject;
import java.util.Base64;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class RunClient {
	
	private final static String _SERVER = "127.0.0.1";
	private final static int _PORT = 8888;
	public static String CA_Address;
	public static int CA_PORT;
	
	private static String password = "";
	
	static final String ANSI_RESET = "\u001B[0m";
    static final String ANSI_RED = "\u001B[31m";

	public static void main(String[] args) throws Exception {
		
		GroupClient gc = new GroupClient();
		FileClient fc = new FileClient();
		
		String username = null;
		Scanner read = new Scanner(System.in);
		
		
		String time = "";
		for(int i = 0; i < 1; i++) {
		while(true) {
			long start = System.currentTimeMillis();
			if(args.length > 5) {
				// client can select specific ip and port to connect
				// need 4 arguments
				String gip = args[0];
				String gport = args[1];
				gc.connect(gip, Integer.parseInt(gport));	
				
				String fip = args[2];
				String fport = args[3];
				fc.connect(fip, Integer.parseInt(fport));	
				
				CA_Address = args[4];
				CA_PORT = Integer.parseInt(args[5]);
							
			} else {
				// not enough argument, then follow the hard code solution
				gc.connect(_SERVER, GroupServer.SERVER_PORT);
				fc.connect(_SERVER, FileServer.SERVER_PORT);
				CA_Address = "127.0.0.1";
				CA_PORT = 9999;
			}
			
			
			System.out.print("Please enter your username: ");
			//username = read.next();
			username = "egan";
			String input;
			
   			// create symmetric key for client and group server
   			String gs_challenge = gc.generateSymmetricKey(username);
   			
   			//verify symmetric key for client and group server
           if(gs_challenge == null) {
        	   break;
           }
           
            System.out.print("Please enter your password: ");
   			//password = read.next();
            password = "123";
   			
	   		MessageDigest md;
	   		byte[] hashed_password;
	   		boolean if_password_match = false;
			try {
				md = MessageDigest.getInstance("SHA-256");
				md.update(password.getBytes("UTF-8"));
		   		hashed_password = md.digest();
		   		if_password_match = gc.userPassword(username, hashed_password, gs_challenge);
			} catch (Exception e) {
				System.out.println("client cannot hash its password");
				e.printStackTrace();
				break;
			}
	        	   
	        if(!if_password_match) {
	        	System.out.print("Failed to login...");
	        	break;
	        }else {
	        	
	        	SignedObject token = null;
	        	
	        	PublicKey fs_public_key = fc.generateSymmetricKey(username, CA_Address, CA_PORT);
	        	
	        	token =(SignedObject)gc.getToken(username, fs_public_key);
	        	
				if(!fc.client_authenticate_fs(fs_public_key, token)) {
					 break;
				}
				
	        	do {
					System.out.printf("*** [%s] *** \n", username);
					
					//input = readSomeText();
					input = "EXIT";
				
					if (input.equals("CUSER")) {
						System.out.print("Please enter the username you want to create: ");
						gc.createUser(read.next(), token);
					}
					else if (input.equals("DUSER")) {
						System.out.print("Please enter the username you want to delete: ");
						gc.deleteUser(read.next(), token);
					}
					else if (input.equals("CGROUP")) {
						System.out.print("Please enter group name to create group: ");
						gc.createGroup(read.next(), token);
					}
					else if (input.equals("DGROUP")) {
						System.out.print("Please enter the name of the group you wish to delete: ");
						gc.deleteGroup(read.next(), token);
					}
					else if (input.equals("LMEMBERS")) {
						System.out.print("Please enter the group name of which the members you wish to know: ");
						List<String> list = gc.listMembers(read.next(), token);
						if(list != null)
							for(String member: list){
								System.out.printf("-" + member + "\n");
							}
						else {
							System.out.println("Group doesn't exist.");
						}
					}
					else if (input.equals("AUSERTOGROUP")) {
						System.out.print("Please enter the username you wish to add: ");
						String usrname = read.next();
						System.out.print("Please enter the groupname you wish to add " + usrname + " to: ");
						String grp = read.next();
						gc.addUserToGroup(usrname, grp, token);
					}
					else if (input.equals("RUSERFROMGROUP")) {
						System.out.print("Please enter the username you wish to delete: ");
						String usrname = read.next();
						System.out.print("Please enter the groupname you wish to delete " + usrname + " from: ");
						String grp = read.next();
						gc.deleteUserFromGroup(usrname, grp, token);
					}
					/*
					else if (input.equals("CHATROOM")) {
						System.out.print("Please enter the group you want to talk with: ");
						String chatgroup = read.next();
						gc.createChatRoom(chatgroup, token);
					}
					*/
					
					else if (input.equals("LGROUP")) {
						System.out.print("Please enter user name: ");
						String usrname = read.next();
						gc.listGroup(token, usrname);
					}
					
					else if (input.equals("CHECKPROFILE")) {
						System.out.print("Whose profile you want to check: ");
						String usrname = read.next();
						gc.checkProfile(token, usrname);
					}

					else if (input.equals("SETPRIVACY")) {
						System.out.print("0: Private, 1: Public \n");
						System.out.print("Which privacy level: ");
						String level = read.next();
						if(level.equals("0") || level.equals("1")) {
							gc.setPrivacy(token, Integer.parseInt(level));
						} else {
							System.err.println("Invalid privacy level");
						}
					}
					
					else if(input.equals("SETPROFILE")) {
						System.out.print("First Name: ");
						String firstN = read.next();
						System.out.print("Last Name: ");
						String lastN = read.next();
						System.out.print("Age: ");
						String age = read.next();
						boolean num = true;
						for(char c: age.toCharArray())
					        if(!Character.isDigit(c)) {
					        	num = false;
					        }	
						if(num){
							System.out.print("Content: ");
							BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
							String content = "";
							try {
								content = in.readLine();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							gc.setProfile(token, firstN, lastN, Integer.parseInt(age), content);
							
						} else {
							System.err.println("Not a valid number for age");
						}
						
					}
					
					
					else if (input.equals("LFILES")) {
						fc.listFiles(token);
					}
					else if (input.equals("UPLOADF")) {
						System.out.print("Please enter the group that you want to share your file with: ");
						String groupName = read.next();
						System.out.print("Enter the path to the local file to upload: ");
						String path = read.next();
						System.out.print("Enter the filename to use on the server: ");
						String fileName = read.next();
						int group_n = gc.getGroupN(token, groupName);
						SecretKey hashedKey = gc.getHashedGroupKey(token, groupName);
						if(hashedKey.equals(null)) {
							System.out.println("Not a group member");
							break;
						}
						System.out.println("hasedKey: " + hashedKey);
						System.out.println("group_n is " + group_n);
						// encrypt file before upload	
						byte[] randIV = randomIV();
						String file_e = encryptFile(path, hashedKey, randIV);
						if(!file_e.equals(null)) {		
							System.out.println("UP");
							fc.upload(file_e, fileName, groupName, token, group_n, randIV);
							File f = new File(file_e);
							if(f.exists())
								f.delete();	
						} else {
							System.out.println("File not exist!");
						}
					}
					else if (input.equals("DOWNLOADF")) {
						System.out.print("Enter the filename used on the server: ");
						String fileName_server = read.next();
						System.out.print("Enter the filename to use locally: ");
						String fileName_local = read.next();
						fileName_local = fileName_local.substring(0, fileName_local.length()-4) + "_e.txt";
						fc.download(fileName_server, fileName_local, token);
						
						System.out.println("Downloaded File");
						String groupName = fc.getFileGroup(fileName_server, token);
						// key information from group server
						int n_fromGS = gc.getGroupN(token, groupName);
						SecretKey hashedKey = gc.getHashedGroupKey(token, groupName);
						// file information from file server
						int n_fromFS = fc.getFileN(fileName_server, token);
						byte[] IV = fc.getFileIV(fileName_server, token);
						
						System.out.printf("Group N: %d, File N: %d\n", n_fromGS, n_fromFS);
						
						if(n_fromGS != -1) {
							try {
								decrypFile(hashedKey, n_fromGS, n_fromFS, fileName_local, IV);
							} catch (NoSuchAlgorithmException e) {
								e.printStackTrace();
							}
						}
					}
					else if (input.equals("DELETEF")) {
						System.out.print("Enter the filename to delete: ");
						String fileName = read.next();
						fc.delete(fileName, token);
					} 
					else if (input.toUpperCase().equals("EXIT")){
						System.out.println("User Exit...");
					}
					else {
						System.err.println("Undefined Functionality, please try again.");
					}
	        	}while (!input.toUpperCase().equals("EXIT"));
	    	}
	        gc.Disconnect();
    		fc.Disconnect();
    		long end = System.currentTimeMillis();
    		time = time + Long.toString(end-start) + "\n";
    		break;
		} 	
		TimeUnit.SECONDS.sleep(1);
		}
		System.err.println(time);
		
	}

	private static String readSomeText() {
		
		try{
		    System.out.println("Enter a line of text, or type \"EXIT\" to quit.");
		    System.out.print(" > ");	
		    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		    return in.readLine().toUpperCase();
		} catch (Exception e) {
			System.err.println("Error:" + e.getMessage());
			return "";
		}
	}
	
	private static byte[] randomIV() {
		byte[] IV = new byte[16];
        SecureRandom random = new SecureRandom();
        random.nextBytes(IV);
        return IV;
	}
	
	private static String encryptFile(String file, SecretKey key, byte[] IV){
		StringBuffer sb = new StringBuffer();
		String filename = file.toString();
		filename = filename.substring(0, filename.length()-4);
		
		// Read file
		try {
			File fin = new File(file);
			if(fin.exists()) {
				BufferedReader br = new BufferedReader(new FileReader(fin));
				String line = "";
				System.out.print("Reading file .");
				while((line = br.readLine()) != null) {
					sb.append(line + "\n");
					System.out.print(".");
				}
				System.out.println("");
			} else {
				return null;
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		try {	
			// Create encrypting file
			File fout = new File(filename + "_e.txt");	
			if(!fout.exists()) 
				fout.delete();
			fout.createNewFile();
			
			System.out.println(fout + " created");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			IvParameterSpec ivSpec = new IvParameterSpec(IV);
			cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
			CipherOutputStream cos = new CipherOutputStream(new FileOutputStream(fout), cipher);
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(cos));
			pw.write(sb.toString());
			System.out.println("Finish encrypting");
			pw.close();
			
			String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());
			System.out.println("This is key to encrypt: " + encodedKey);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return filename+"_e.txt";
	}
	
	private static void decrypFile(SecretKey key, int n_g, int n_f, String filename, byte[] IV) throws NoSuchAlgorithmException {
		// how much time client needs to hash key
		int n = n_f - n_g;
		SecretKey fileKey = SHA2(key, n);
		System.out.println("key generated");
		
		String encodedKey = Base64.getEncoder().encodeToString(fileKey.getEncoded());
		System.out.println("This is key to decrypt: " + encodedKey);
		File resoure = new File(filename);
		File file = new File(filename);
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			IvParameterSpec ivSpec = new IvParameterSpec(IV);
			cipher.init(Cipher.DECRYPT_MODE, fileKey, ivSpec);
			CipherInputStream cis = new CipherInputStream(new FileInputStream(file), cipher);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

            byte[] b = new byte[1024];
            int numberOfBytedRead;
            while ((numberOfBytedRead = cis.read(b)) >= 0) {
                baos.write(b, 0, numberOfBytedRead);
            }
            
            String outputS = new String(baos.toByteArray());
            
            String outputFilename = filename.substring(0, filename.length()-6) + ".txt";
            File folder = new File("download");
            if(!folder.exists()) {
            	folder.mkdirs();
            }
            File fout = new File("download/" + outputFilename);
            FileOutputStream fos = new FileOutputStream(fout);
            fos.write(baos.toByteArray());
            fos.close();
            
            resoure.delete();
            
			
		} catch (Exception e) {
			System.err.println("You might use the wrong key to decrypt file");
		}	
		
	}
	
	private static SecretKey SHA2(SecretKey key, int n) throws NoSuchAlgorithmException {			
		
		MessageDigest sha256 = MessageDigest.getInstance("SHA-256");  
		byte[] keyBytes = key.getEncoded();
		
		// apply SHA2 to key n times
		for(int i=0; i < n; i++) 
			keyBytes = sha256.digest(keyBytes);
		
		// turn it back to SecretKey
		SecretKey hasedKey = new SecretKeySpec(keyBytes, 0, keyBytes.length, "AES");
		
	    return hasedKey;
	}
	
}
