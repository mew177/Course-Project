/* FileServer loads files from FileList.bin.  Stores files in shared_files directory. */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;


public class FileServer extends Server {
	
	public static final int SERVER_PORT = 4321;
	public static final int CA_PORT = 9999;
	public static FileList fileList;
	public static String FILE_SERVER_NAME;
	public static String CA_address;
	private static KeyPair FileServerKeypair;
	
	
	static final String ANSI_RESET = "\u001B[0m";
    static final String ANSI_RED = "\u001B[31m";
    
    static final KeyPair pair = null;
	
	public FileServer() {
		super(SERVER_PORT, "FilePile");		
		FILE_SERVER_NAME = generateName();
		CA_address = "127.0.0.1";
	}

	public FileServer(int _port, String CA) {
		super(_port, "FilePile");
		FILE_SERVER_NAME = generateName();
		CA_address = CA;
	}
	
	public void start() {
		String fileFile = "FileList.bin";
		ObjectInputStream fileStream;
		
		//This runs a thread that saves the lists on program exit
		Runtime runtime = Runtime.getRuntime();
		Thread catchExit = new Thread(new ShutDownListenerFS());
		runtime.addShutdownHook(catchExit);
		
		//Open user file to get user list
		try
		{
			FileInputStream fis = new FileInputStream(fileFile);
			fileStream = new ObjectInputStream(fis);
			fileList = (FileList)fileStream.readObject();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("FileList Does Not Exist. Creating FileList...");
			
			fileList = new FileList();
			
		}
		catch(IOException e)
		{
			System.out.println("Error reading from FileList file");
			System.exit(-1);
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("Error reading from FileList file");
			System.exit(-1);
		}
		
		File file = new File("shared_files");
		 if (file.mkdir()) {
			 System.out.println("Created new shared_files directory");
		 }
		 else if (file.exists()){
			 System.out.println("Found shared_files directory");
		 }
		 else {
			 System.out.println("Error creating shared_files directory");				 
		 }
		
		//Autosave Daemon. Saves lists every 5 minutes
		AutoSaveFS aSave = new AutoSaveFS();
		aSave.setDaemon(true);
		aSave.start();
				
		boolean running = true;
		Socket sock = null;
		Thread thread = null;
		
		try
		{			
			final ServerSocket serverSock = new ServerSocket(port);
			System.out.printf("%s up and running\n", this.getClass().getName());
			
			FileServerKeypair = getKeyPair();
			addPublicKeyToCA();
			
			while(running)
			{
				sock = serverSock.accept();
				thread = new FileThread(sock, this, FileServerKeypair);
				thread.start();
			}
			
			System.out.printf("%s shut down\n", this.getClass().getName());
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
			try {
				sock.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public void saveFile() {
		ObjectOutputStream outStream;
		try
		{
			outStream = new ObjectOutputStream(new FileOutputStream("FileList.bin"));
			outStream.writeObject(FileServer.fileList);
			
			System.out.print(ANSI_RED);
			System.out.println("FileList Saved!");
			System.out.print(ANSI_RESET);
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
		
		
	
	}


	public void loadFile() {
		String fileFile = "FileList.bin";
		ObjectInputStream fileStream;
		try
		{
			FileInputStream fis = new FileInputStream(fileFile);
			fileStream = new ObjectInputStream(fis);
			fileList = (FileList)fileStream.readObject();
			
			System.out.print(ANSI_RED);
			System.out.println("FileList Loaded!");
			System.out.print(ANSI_RESET);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	private static KeyPair getKeyPair() throws NoSuchAlgorithmException {
		KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
	    generator.initialize(1024, new SecureRandom());
	    KeyPair pair = generator.generateKeyPair();
	    
		return pair;
	}
	
	private static void addPublicKeyToCA() throws IOException {
		
		// connected to CA
		CAclient cc = new CAclient();
		cc.connect(CA_address, CA_PORT);
				
		// add public key to envelope
		Envelope post = new Envelope("POSTF");
		post.addObject(FILE_SERVER_NAME);
		post.addObject(FileServerKeypair.getPublic());
		System.out.println("Sending Key to CA");
				
		// send envelope
		cc.output.writeObject(post);
		System.out.println("Public Key Posted");
				
		cc.disconnect();
		
	}
	
	private static String generateName() {
		
		final int PASSWORD_LEN = 5;
		
		String elements = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder sb = new StringBuilder();
		sb.append("FILE_");
		Random random = new Random(System.currentTimeMillis());
		for(int k = 0; k < PASSWORD_LEN; k++) {
			sb.append(elements.charAt(random.nextInt(elements.length())));
		}
		
		return sb.toString();
	}
}



//This thread saves user and group lists
class ShutDownListenerFS implements Runnable
{
	public void run()
	{
		System.out.println("Shutting down server");
		ObjectOutputStream outStream;

		try
		{
			outStream = new ObjectOutputStream(new FileOutputStream("FileList.bin"));
			outStream.writeObject(FileServer.fileList);
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
	}
}

class AutoSaveFS extends Thread
{
	public void run()
	{
		do
		{
			try
			{
				Thread.sleep(300000); //Save group and user lists every 5 minutes
				System.out.println("Autosave file list...");
				ObjectOutputStream outStream;
				try
				{
					outStream = new ObjectOutputStream(new FileOutputStream("FileList.bin"));
					outStream.writeObject(FileServer.fileList);
				}
				catch(Exception e)
				{
					System.err.println("Error: " + e.getMessage());
					e.printStackTrace(System.err);
				}

			}
			catch(Exception e)
			{
				System.out.println("Autosave Interrupted");
			}
		}while(true);
	}
	
	
}
