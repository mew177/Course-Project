/* Implements the GroupClient Interface */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.SignedObject;

public class GroupClient extends Client implements GroupClientInterface {
	
	private SecretKey clientSymmetricKey;
	private SecretKey integrity_key;
	private Cipher client_cipher_encrypt;
	private Cipher client_cipher_decrypt;
	private int sequenceNumber;
	private byte[] iv = {122, 51, 6, 17, 79, 41, 34, 18, -125, -15, 108, 63, -41, 125, 67, 34};
	
	public String generateSymmetricKey(String username){
		try
		{
			PublicKey serverPublic = null;
			Envelope message = null, response = null;
			

			KeyPair clientKeyPair = DiffieHellman.genKeyPair();
   			KeyAgreement keyAgreement = DiffieHellman.genKeyAgreement(clientKeyPair);
   			
			message = new Envelope("Generate_Shared_Key");
			message.addObject(username); //Add user name string
			message.addObject(clientKeyPair.getPublic()); //Add user public key
			output.writeObject(message);
			
		
			//Get the response from the server
			response = (Envelope)input.readObject();
			
			//Successful response
			if(response.getMessage().equals("OK"))
			{
				//If there is a token in the Envelope, return it 
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					SignedObject signedServerPublic = (SignedObject)temp.get(0);
					SignedObject signed_gs_challenge = (SignedObject)temp.get(1);
		   			serverPublic = (PublicKey)signedServerPublic.getObject();
		   			byte[] cipherChallenge = (byte[])signed_gs_challenge.getObject();
		   			
				    clientSymmetricKey = DiffieHellman.generateSecretKey(serverPublic, keyAgreement);
		            System.out.println("client symmetric key is " + Base64.getEncoder().encodeToString(clientSymmetricKey.getEncoded()));
		            
		            client_cipher_encrypt = Cipher.getInstance("AES"); 
		            client_cipher_encrypt.init(Cipher.ENCRYPT_MODE, clientSymmetricKey);
		            
		            client_cipher_decrypt = Cipher.getInstance("AES"); 
		            client_cipher_decrypt.init(Cipher.DECRYPT_MODE, clientSymmetricKey);
		            String groupServer_challenge = new String(client_cipher_decrypt.doFinal(cipherChallenge));
		            
					return groupServer_challenge;
				}
			}
			System.out.printf("Failed to get group server's public key. \n");
			return null;
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
			return null;
		}

	}
	
	public boolean userPassword(String username, byte[] hashPassword, String gs_challenge) {
		try
		{
			Envelope message = null, response = null;
			
			Random rand = new Random();
			sequenceNumber = rand.nextInt();
			System.out.println("Client set sequence number initially as " + sequenceNumber+" with group server");
		 		 	
			//Tell the server to return a token.
			message = new Envelope("User_Password_Check");
			message.addObject(username); 
			message.addObject(hashPassword);
			message.addObject(gs_challenge);
			message.addObject(sequenceNumber);
			//System.out.println("User_Password_Check");
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
		
			//Decrypt the response from the server
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			//Successful response
	
			if(response.getMessage().equals("OK"))
			{
				int gs_sq_num = (int)response.getObjContents().get(0);
				
				System.out.printf("Sequence number now is %d, sq in the message is %d. \n", sequenceNumber, gs_sq_num);
				
				if(gs_sq_num == (sequenceNumber+1)) {
					sequenceNumber = gs_sq_num;
					String temp = clientSymmetricKey.toString() + "Integrity";
					try {
						MessageDigest md = MessageDigest.getInstance("SHA-256");
						md.update(temp.getBytes("UTF-8"));
						byte[] integrate_hash = md.digest();
						integrity_key = new SecretKeySpec(integrate_hash, 0, integrate_hash.length, "AES");
						
						System.out.println("Client's integrate key is " 
								+ Base64.getEncoder().encodeToString(integrity_key.getEncoded()));
						
						return true;
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("client generate integrity key fail");
						return false;
					}
		   			
				}else {
					return false;
				}
				
			} else if(response.getMessage().equals("LOCKED")){
				System.out.printf("Your account has been locked \n");
				return false;
			}
			
			System.out.printf("Password is not correct. \n");
			return false;
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
			return false;
		}
	}
	
	public void Disconnect() {
			try
			{
				Envelope message = new Envelope("DISCONNECT");
				Envelope m = new Envelope("message");
				sequenceNumber = sequenceNumber+1;
				m.addObject(sequenceNumber);
				message.addObject(m);
				message.addObject(getMessageHMAC(m.getObjContents()));
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);	
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
			}
		
	}
	
	
//------------------------group server function-------------------------------------
	
	public boolean checkHMAC(byte[] client_msg_hash, ArrayList<Object> message) throws Exception {
		
		byte[] group_msg_hash = getMessageHMAC(message);
		
		if(MessageDigest.isEqual(group_msg_hash, client_msg_hash)) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public static byte[] concatenateArrays(byte[] arr1, byte[] arr2) {
		byte[] arr3 = new byte[arr1.length + arr2.length];
		for (int i = 0; i < arr1.length; i++) {
			arr3[i] = arr1[i];
		}
		for (int i = 0; i < arr2.length; i++) {
			arr3[i + arr1.length] = arr2[i];
		}
		return arr3;
	}
	
	public byte[] getMessageHMAC(ArrayList<Object> message) throws Exception {
		byte[] hmac = null;
		//byte[] content = concatenateArrays(message.toString().getBytes(), iv);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(message);
		oos.flush();
		byte[] content = bos.toByteArray();
		
		try {		
			Mac mac = Mac.getInstance("HmacSHA256");
			mac.init(integrity_key);
			hmac = mac.doFinal(content);
			//System.out.println("content is " +Arrays.toString(content));
			//System.out.println("hmac(m) is " +Arrays.toString(hmac));
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return hmac;
	}

	
 
	public SignedObject getToken(String username, PublicKey fs_public ) {
		try {
			SignedObject signedtoken = null;
			Envelope message = null, response = null;
			// Tell the server to return a token.
			message = new Envelope("GET");
			sequenceNumber = sequenceNumber+1;
			Envelope m = new Envelope("message");
			m.addObject(username); // Add user name string
			m.addObject(fs_public);
			m.addObject(sequenceNumber);
			
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			

			// Decrypt the response from the server
			SealedObject encrypt_msg = (SealedObject) input.readObject();
			response = (Envelope) encrypt_msg.getObject(client_cipher_decrypt);

			// Successful response
			if (response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						signedtoken = (SignedObject) msg.getObjContents().get(0);
						int response_sq = (int)msg.getObjContents().get(1);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("msg match \n");
								System.out.printf("Successfully got %s's token. \n", username);
								return signedtoken;
							}	
						}
					}
					
				}

			}else {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("Failed to get %s's token. \n", username);
								return null;
							}
						}
					}
				}
			}

			System.out.printf("Failed to get %s's token. \n", username);
			return null;
			
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
			return null;
		}

	}
	 
	 public boolean createUser(String username, SignedObject token)
	 {
		 try
			{
				Envelope message = null, response = null;
				//Tell the server to create a user
				message = new Envelope("CUSER");
				Envelope m = new Envelope("message");
				m.addObject(username); 
				m.addObject(token); //Add the requester's token
				sequenceNumber = sequenceNumber+1;
				m.addObject(sequenceNumber);
				message.addObject(m);
				message.addObject(getMessageHMAC(m.getObjContents()));
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				//Get the response from the server
				SealedObject encrypt_msg = (SealedObject)input.readObject();
				response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
				System.out.printf("Decrypting response... \n");
	
			
				if(response.getMessage().equals("OK"))
				{
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							
							int sq_num = (int)msg.getObjContents().get(0);
							if(sq_num == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									
									System.out.printf("Successfully add '%s'. \n", username);
									return true;
								}
							}
						}
					}
					System.out.printf("Fail to add '%s'. \n", username);
					return false;
				}else {
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									
									System.out.printf("Failed to get %s's token. \n", username);
									return false;
								}
							}
						}
					}
				}
				
				System.out.printf("Failed to add '%s'. \n", username);
				return false;
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
				return false;
			}
	 }
	 
	 public boolean deleteUser(String username, SignedObject token)
	 {
		 try
			{
				Envelope message = null, response = null;
			 
				//Tell the server to delete a user
				message = new Envelope("DUSER");
				Envelope m = new Envelope("message");
				m.addObject(username); //Add user name
				m.addObject(token);  //Add requester's token
				sequenceNumber = sequenceNumber+1;
				m.addObject(sequenceNumber);
				message.addObject(m);
				message.addObject(getMessageHMAC(m.getObjContents()));
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				//Get the response from the server
				SealedObject encrypt_msg = (SealedObject)input.readObject();
				response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
				System.out.printf("Decrypting response... \n");
				
				//If server indicates success, return true
				if(response.getMessage().equals("OK"))
				{
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int sq_num = (int)msg.getObjContents().get(0);
							if(sq_num == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("Successfully delete '%s'. \n", username);
									return true;
								}
							}
						}
					}
					System.out.printf("Fail to delete '%s'. \n", username);
					return false;
				}else {
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									
									System.out.printf("Failed to delete '%s'. \n", username);
									return false;
								}
							}
						}
					}
				}
				
				System.out.printf("Failed to delete '%s'. \n", username);
				return false;
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
				return false;
			}
	 }
	 
	 public boolean createGroup(String groupname, SignedObject token)
	 {
		 try
			{
				Envelope message = null, response = null;
				//Tell the server to create a group
				message = new Envelope("CGROUP");
				
				Envelope m = new Envelope("message");
				m.addObject(groupname); //Add the group name string
				m.addObject(token); //Add the requester's token
				sequenceNumber = sequenceNumber+1;
				m.addObject(sequenceNumber);
				
				message.addObject(m);
				message.addObject(getMessageHMAC(m.getObjContents()));
				
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				//Get the response from the server
				SealedObject encrypt_msg = (SealedObject)input.readObject();
				response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
				System.out.printf("Decrypting response... \n");
				
				//If server indicates success, return true
				if(response.getMessage().equals("OK"))
				{
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							
							int sq_num = (int)msg.getObjContents().get(0);
							if(sq_num == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("Successfully created group '%s'. \n", groupname);
									return true;
								}
							}
						}
					}
					System.out.printf("Failed to create group '%s'. \n", groupname);
					return false;
				}else {
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("Failed to create group '%s'. \n", groupname);
									return false;
								}
							}
						}
					}
				}
				
				System.out.printf("Failed to create group '%s'. \n", groupname);
				return false;
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
				return false;
			}
	 }
	 
	 public boolean deleteGroup(String groupname, SignedObject token)
	 {
		 try
			{
				Envelope message = null, response = null;
				//Tell the server to delete a group
				message = new Envelope("DGROUP");
				Envelope m = new Envelope("message");
				m.addObject(groupname); //Add the group name string
				m.addObject(token); //Add the requester's token
				sequenceNumber = sequenceNumber+1;
				m.addObject(sequenceNumber);
				
				message.addObject(m);
				message.addObject(getMessageHMAC(m.getObjContents()));
				
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				//Get the response from the server
				SealedObject encrypt_msg = (SealedObject)input.readObject();
				response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
				System.out.printf("Decrypting response... \n");
			
				
				//If server indicates success, return true
				if(response.getMessage().equals("OK"))
				{
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							
							int sq_num = (int)msg.getObjContents().get(0);
							if(sq_num == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("Successfully delete group '%s'. \n", groupname);
									return true;
								}
							}else {
								System.out.printf("sequence number not match");
								return false;
							}
						}
					}
					System.out.printf("Failed to delete group '%s'. \n", groupname);
					return false;
				}else {
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("Failed to delete group '%s'. \n", groupname);
									return false;
								}
							}
						}
					}
				}
				
				System.out.printf("Failed to delete group '%s'. \n", groupname);
				return false;
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
				return false;
			}
	 }
	 
	 @SuppressWarnings("unchecked")
	public List<String> listMembers(String group, SignedObject token)
	 {
		 try
		 {
			 Envelope message = null, response = null;
			 //Tell the server to return the member list
			 message = new Envelope("LMEMBERS");
			 
			 Envelope m = new Envelope("message");
			 m.addObject(group); //Add the group name string
		     m.addObject(token); //Add the requester's token
		     sequenceNumber = sequenceNumber+1;
		  	 m.addObject(sequenceNumber);
				
			 message.addObject(m);
			 message.addObject(getMessageHMAC(m.getObjContents()));
			 SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			 output.writeObject(sealed_msg);
				
				//Get the response from the server
			 SealedObject encrypt_msg = (SealedObject)input.readObject();
			 response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			 System.out.printf("Decrypting response... \n");
			  
			 
			 //If server indicates success, return the member list
			 if(response.getMessage().equals("OK"))
			 { 
				 ArrayList<Object> temp = null;
				 temp = response.getObjContents();
					
				 if(temp.size() == 2)
			     {
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
					if(msg.getObjContents().size() == 2) {
						
						int sq_num = (int)msg.getObjContents().get(1);
					
						if(sq_num == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("Successfully got member list of group '%s'. \n", group);
								return (List<String>)msg.getObjContents().get(0);
							}
						}
					}
			     }
		
				 System.out.printf("Fail to get member list of group '%s'. \n", group);
				 return null;
			 }else {
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									 System.out.printf("Fail to get member list of group '%s'. \n", group);
									return null;
								}
							}
						}
					}
				}
			 System.out.printf("Fail to get member list of group '%s'. \n", group);
			 return null;
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
			return null;
		}
	 }
	 
	 public boolean addUserToGroup(String username, String groupname, SignedObject token)
	 {
		 try
			{
				Envelope message = null, response = null;
				//Tell the server to add a user to the group
				message = new Envelope("AUSERTOGROUP");
				Envelope m = new Envelope("message");
			    m.addObject(username); //Add user name string
				m.addObject(groupname); //Add group name string
				m.addObject(token); //Add requester's token
				sequenceNumber = sequenceNumber+1;
		     	m.addObject(sequenceNumber);
					
				message.addObject(m);
				message.addObject(getMessageHMAC(m.getObjContents()));
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				//Get the response from the server
				SealedObject encrypt_msg = (SealedObject)input.readObject();
				response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
				System.out.printf("Decrypting response... \n");
				
				
				if(response.getMessage().equals("OK"))
				{
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							
							int sq_num = (int)msg.getObjContents().get(0);
							if(sq_num == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									
									System.out.printf("Successfully added '%s' to group '%s'. \n", username, groupname);
									return true;
								}
							}else {
								System.out.printf("sequence number not match");
								return false;
							}
						}
					}
					System.out.printf("Fail to add '%s' to group '%s'. \n", username, groupname);
					return false;
					
				}else {
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("Fail to add '%s' to group '%s'. \n", username, groupname);
									return false;
								}
							}
						}
					}
				}
				System.out.printf("Fail to add '%s' to group '%s'. \n", username, groupname);
				return false;
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
				return false;
			}
	 }
	 
	 public boolean deleteUserFromGroup(String username, String groupname, SignedObject token)
	 {
		 try
			{
				Envelope message = null, response = null;
				//Tell the server to remove a user from the group
				message = new Envelope("RUSERFROMGROUP");
				Envelope m = new Envelope("message");
				m.addObject(username); //Add user name string
				m.addObject(groupname); //Add group name string
				m.addObject(token); //Add requester's token
				sequenceNumber = sequenceNumber+1;
		     	m.addObject(sequenceNumber);
					
				message.addObject(m);
				message.addObject(getMessageHMAC(m.getObjContents()));
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				//Get the response from the server
				SealedObject encrypt_msg = (SealedObject)input.readObject();
				response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
				System.out.printf("Decrypting response... \n");
				
				//If server indicates success, return true
				if(response.getMessage().equals("OK"))
				{
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							
							int sq_num = (int)msg.getObjContents().get(0);
							if(sq_num == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									
									System.out.printf("Successfully deleted '%s' from group '%s'. \n", username, groupname);
									return true;
								}
							}else {
								System.out.printf("sequence number not match");
								return false;
							}
						}
					}
					System.out.printf("Failed to delete '%s' from group '%s'. \n", username, groupname);
					return false;
					
				}else {
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("Failed to delete '%s' from group '%s'. \n", username, groupname);
									return false;
								}
							}
						}
					}
				}
				
				System.out.printf("Failed to delete '%s' from group '%s'. \n", username, groupname);
				return false;
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
				return false;
			}
	 }
	 
	 /*
	 public void createChatRoom(String group, SignedObject token) {
		 try {
			 Envelope message = null, response = null;
			 message = new Envelope("CHATROOM");
			 message.addObject(group); //Add group name
			 message.addObject(token); //Add requester's token
			 SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			 System.out.println("##1##");
			 output.writeObject(sealed_msg);
			 
			 System.out.println("##2##");
			 SealedObject encrypt_msg = (SealedObject)input.readObject();
			 response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			 System.out.println("##3##");
			 if(response.getMessage().equals("OK"))
			 {
				 System.out.println("##4##");
				 ChatRoom chatRoom = (ChatRoom)response.getObjContents().get(0);
				 System.out.println("##5##");
				 ChatRoomClient crc = new ChatRoomClient();
				 System.out.println("##6##");
				 crc.connect(chatRoom.get_Address(), chatRoom.get_port());
			 }
			 
		 } catch(Exception e) {
			 System.err.println("Error: " + e.getMessage());
			 e.printStackTrace(System.err);
		 }
	 }
	*/

	public void listGroup(SignedObject token, String usrname) {
		try {
			Envelope message = null, response = null;
			message = new Envelope("LGROUP");
			Envelope m = new Envelope("message");
			m.addObject(token); //Add requester's token
			m.addObject(usrname); //Add user name string
			sequenceNumber = sequenceNumber+1;
	     	m.addObject(sequenceNumber);
				
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						
						List<String> groups = (List<String>)msg.getObjContents().get(0); 
						int sq_num = (int)msg.getObjContents().get(1);
						
						if(sq_num == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								if (groups.equals(null)) {
									System.out.println("Didn't get group information from server.");
									System.out.println("Maybe you are not belong in any group.");
								} else {
									System.err.printf("%s's group list: \n", usrname);
									int count = 1;
									for(String group: groups) {
										System.out.printf("#%d. %s \n", count++, group);
									}
								}
							}
						}else {
							System.out.printf("sequence number not match");
						}
					}
				}
			}else {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("Fail to list '%s' group. \n", usrname);
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	public void checkProfile(SignedObject token, String usrname) {
		
		try {
			Envelope message = null, response = null;
			message = new Envelope("CHECKPROFILE");
			Envelope m = new Envelope("message");
			m.addObject(token); //Add requester's token
			m.addObject(usrname); //Add user name string
			sequenceNumber = sequenceNumber+1;
	     	m.addObject(sequenceNumber);
				
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						
						ArrayList<String> profile = null; 
						profile = (ArrayList<String>) msg.getObjContents().get(0);
						int sq_num = (int)msg.getObjContents().get(1);
						
						if(sq_num == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								if(!profile.equals(null)) {
									System.out.printf("|== %s Profile ======= \n", usrname);
									System.out.printf("|Firstname |: %s \n", profile.get(0));
									System.out.printf("|-----------------------\n");
									System.out.printf("|Lastname  |: %s \n", profile.get(1));
									System.out.printf("|-----------------------\n");
									System.out.printf("|Age       |: %s \n", profile.get(2));
									System.out.printf("|-----------------------\n");
									System.out.printf("|Content:\n");
									System.out.printf("|%s \n", profile.get(3));
									System.out.printf("|===================== \n", usrname);
								} else {
									System.err.println("No profile can show");
								}
							}
						}
					}
				}
			} else {
			
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.err.println("Connot find the user profile.");
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	public void setPrivacy(SignedObject token, int level) {
		try {
			Envelope message = null, response = null;
			message = new Envelope("SETPRIVACY");
			Envelope m = new Envelope("message");
			m.addObject(token);
			m.addObject(level);
			sequenceNumber = sequenceNumber+1;
	     	m.addObject(sequenceNumber);
				
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int sq_num = (int)msg.getObjContents().get(0);
						
						if(sq_num == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								System.out.println("Your profile has set to privacy level " + String.valueOf(level));
							}
						}
					}
				}
			} else {
				
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.println("Fail to set privacy");
							}
						}
					}
				}
			}			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void setProfile(SignedObject token, String firstname, String lastname, int age, String content ) {
		try {
			Envelope message = null, response = null;
			message = new Envelope("SETPROFILE");
			Envelope m = new Envelope("message");
			m.addObject(token);
			m.addObject(firstname);
			m.addObject(lastname);
			m.addObject(age);
			m.addObject(content);
			sequenceNumber = sequenceNumber+1;
	     	m.addObject(sequenceNumber);
				
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int sq_num = (int)msg.getObjContents().get(0);
						
						if(sq_num == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								System.out.println("Your profile is set");
							}
						}
					}
				}
			} else {
				
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.println("Fail to set privacy");
							}
						}
					}
				}
			}			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public SecretKey getHashedGroupKey(SignedObject token, String group) {
		SecretKey groupkey = null;
		
		try {
			Envelope message = null, response = null;
			message = new Envelope("GETGROUPKEY");
			Envelope m = new Envelope("message");
			m.addObject(token);
			m.addObject(group);
			sequenceNumber = sequenceNumber+1;
	     	m.addObject(sequenceNumber);
	     	
	     	message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						groupkey = (SecretKey)msg.getObjContents().get(0);
						int sq_num = (int)msg.getObjContents().get(1);
						
						if(sq_num == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								System.out.println("Get group key");
								return groupkey;
							}
						}
					}
				}
			}else {
					
					ArrayList<Object> temp = null;
					temp = response.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) response.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq == (sequenceNumber+1)) {
								sequenceNumber = sequenceNumber+1;
								
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.println("Fail to get group key information");
								}
							}
						}
					}
			}
				
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return groupkey;
	}
	
	public int getGroupN(SignedObject token, String group) {
		int n = -1;
		try {
			Envelope message = null, response = null;
			message = new Envelope("GETGROUPN");
			Envelope m = new Envelope("message");
			m.addObject(token);
			m.addObject(group);
			sequenceNumber = sequenceNumber+1;
	     	m.addObject(sequenceNumber);
	     	
	     	message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						n = (int)msg.getObjContents().get(0);
						int sq_num = (int)msg.getObjContents().get(1);
						
						if(sq_num == (sequenceNumber+1) ){
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								System.out.println("Get group N");
								return n;
							}
						}
					}
				}
				System.out.println("Fail to get group key information");
			} else {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.println("Fail to get group key information");
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return n;
	}
	
	public boolean reduceGroupN(SignedObject token, String group) {
		try {
			Envelope message = null, response = null;
			message = new Envelope("REDUCEGROUPN");
			Envelope m = new Envelope("message");
			m.addObject(token);
			m.addObject(group);
			sequenceNumber = sequenceNumber+1;
	     	m.addObject(sequenceNumber);
	     	
	     	message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int sq_num = (int)msg.getObjContents().get(1);
						
						if(sq_num == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								System.out.println("Group n has reduced!");
								return true;
							}
						}
					}
				}
			
				System.out.println("Fail to reduce 1");
			}else {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) response.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq == (sequenceNumber+1)) {
							sequenceNumber = sequenceNumber+1;
							
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.println("Fail to reduce 1");
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return false;
	}
	
}
