import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Hashtable;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class GroupList implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3640596306597345734L;
	private Hashtable<String, Group> list = new Hashtable<String, Group>();
	
	public synchronized void addGroup(String groupName)
	{
		// create and group to group list
		Group newgroup = new Group();
		list.put(groupName, newgroup);
		System.out.printf("Group %s created successfully! \n", groupName);
	}
	
	public synchronized void deleteGroup(String groupName)
	{
		// remove content from list with index groupName
		list.remove(groupName);
		System.out.printf("Group %s removed successfully! \n", groupName);
	}
	
	public synchronized boolean checkGroup(String groupName)
	{
		// return true if group name contain in list
		if(list.containsKey(groupName)) {
			System.out.printf("Group %s is in group list! \n", groupName);
			return true;
		}
		// return false if group name doesn't contain in list
		else {
			System.out.printf("Group %s is not in group list! \n", groupName);
			return false;
		}
	}
	
	public synchronized void addMember(String username, String groupName) 
	{
		System.out.println(username + " " + groupName + " " + list.size());
		list.get(groupName).member.add(username);
		System.out.printf("User %s add to group %s successfully! \n", username, groupName);	
	}
	
	public synchronized void removeMember(String username, String groupName) 
	{
		list.get(groupName).member.remove(username);
		System.out.printf("User %s deleted from group %s successfully! \n", username, groupName);	
	}
	
	public synchronized ArrayList<String> getMemberList(String groupName)
	{
		System.out.printf("Member list of group %s is sending to client... \n", groupName);	
		return list.get(groupName).member;
	}
	
	public synchronized SecretKey getGroupKey(String groupName) {
		System.out.printf("Sending group %s key to client... \n", groupName);	
		return list.get(groupName).groupkey;
	}
	
	public synchronized int getN(String groupName) {
		return list.get(groupName).n;
	}
	
	public synchronized void reduceN(String groupName) {
		list.get(groupName).reduceN();
	}

	
	class Group implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 4972931177070688531L;
		private ArrayList<String> member;
		private SecretKey groupkey;
		private int n;
		
		// Group Constructor
		public Group() {
			// Add creator to UserInGroup list
			this.member = new ArrayList<String>();
			this.groupkey = generateAES256();
			this.n = 9999;
			System.out.printf("Successfully created group! \n");
		}
		
		public synchronized void addUserToGroup(String username) {
			member.add(username);
			System.out.printf("User %s added to group successfully! \n", username);
		}
		
		public void reduceN() {
			n--;
			System.out.printf("Remaining n: %d \n", n);
		}
		
		private SecretKey generateAES256() {
			SecretKey key = null;
			try {
				// Generate group block cipher key
				KeyGenerator kg = KeyGenerator.getInstance("AES");
				kg.init(256);
				key = kg.generateKey();
				System.err.println("Group key generated");
				
			} catch (Exception e) {
				e.printStackTrace();
				System.err.println("Err: " + e.getMessage());
			}
			
			return key;		
		}
		
	}
}
