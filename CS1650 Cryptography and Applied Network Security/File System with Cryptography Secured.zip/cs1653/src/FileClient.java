/* FileClient provides all the client functionality regarding the file server */

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SignedObject;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


public class FileClient extends Client implements FileClientInterface {
	
	private static SecretKey clientSymmetricKey;
	private static SecretKey integrity_key;
	private static Cipher client_cipher_encrypt;
	private static Cipher client_cipher_decrypt;
	private int sequenceNumber;
	
	
	public PublicKey generateSymmetricKey(String username, String CA_Address, int CA_PORT){
		try
		{
			PublicKey symmetricPublic = null;
			Envelope message = null, response = null;
			
			KeyPair clientKeyPair = DiffieHellman.genKeyPair();
   			KeyAgreement keyAgreement = DiffieHellman.genKeyAgreement(clientKeyPair);
   			
			message = new Envelope("Generate_Shared_Key");
			message.addObject(username); //Add user name string
			message.addObject(clientKeyPair.getPublic()); //Add user public key
			output.writeObject(message);
			
			//Get the response from the server
			response = (Envelope)input.readObject();
			
			//Successful response
			if(response.getMessage().equals("OK"))
			{
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)//only file server's public key 
				{

					SignedObject signedSymmetricPublic = (SignedObject)temp.get(0);
					String fs_name = (String)temp.get(1);
		   			symmetricPublic = (PublicKey)signedSymmetricPublic.getObject();
				    clientSymmetricKey = DiffieHellman.generateSecretKey(symmetricPublic, keyAgreement);
		            System.out.println("client with file server symmetric key is " + Base64.getEncoder().encodeToString(clientSymmetricKey.getEncoded()));
		            
		            client_cipher_encrypt = Cipher.getInstance("AES"); 
		            client_cipher_encrypt.init(Cipher.ENCRYPT_MODE, clientSymmetricKey);
		            
		            client_cipher_decrypt = Cipher.getInstance("AES"); 
		            client_cipher_decrypt.init(Cipher.DECRYPT_MODE, clientSymmetricKey);
		            
		            PublicKey fs_public_key = getPublicKeyFromCA(fs_name, CA_Address, CA_PORT);
		            System.out.println("file server public key is " + Base64.getEncoder().encodeToString(fs_public_key.getEncoded()));
		            return fs_public_key;//return file server's public key
				}
			}
			System.out.printf("Failed to get file server's public key. \n");
			return null;
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
			return null;
		}

	}
	
	public boolean client_authenticate_fs(PublicKey fs_public, SignedObject token){
		
		try
		{
			
            Random rand = new Random();
            String client_challenge = rand.toString();
            Envelope small_msg = new Envelope("file_server_public_key_verification");
            
			Cipher rsa_cipher = Cipher.getInstance("RSA");
            rsa_cipher.init(Cipher.ENCRYPT_MODE, fs_public);
			SealedObject sealed_challenge = new SealedObject(client_challenge, rsa_cipher);
			
			Random rand1 = new Random();
			sequenceNumber = rand1.nextInt();
			System.out.println("Client set sequence number initially as " + sequenceNumber+" with file server");
		
			Envelope message = null, response = null;
			message = new Envelope("authenticate file server");
			
			message.addObject(sequenceNumber);
			message.addObject(token);
			message.addObject(sealed_challenge);
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			//Get the response from the server
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			System.out.println("decrypt response");
			
			sequenceNumber = sequenceNumber+1;
			if(response.getMessage().equals("OK"))
			{
				System.out.println("File server have gotten token");
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2)
				{
					String s = (String)temp.get(0);
		            int msg_sq = (int)temp.get(1);
		            
					if(msg_sq == sequenceNumber) {
						
						 if(s.equals(client_challenge)) {
							 
							 String temp_s = clientSymmetricKey.toString() + "Integrity";
							 try {
									MessageDigest md = MessageDigest.getInstance("SHA-256");
									md.update(temp_s.getBytes("UTF-8"));
									byte[] integrate_hash = md.digest();
									integrity_key = new SecretKeySpec(integrate_hash, 0, integrate_hash.length, "AES");
									System.out.println("client's integrate key with file server is " 
											+ Base64.getEncoder().encodeToString(integrity_key.getEncoded()));
							 } catch (Exception e) {
									e.printStackTrace();
							 }
								
				             return true;
				         }else {
				             return false;
				         }
					}else {
						System.out.println("sequence number not match");
					}
				}
			}
				
			System.out.printf("File Server get user's token Failed. \n");
			return false;
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
			return false;
		}
	}

	public boolean checkHMAC(byte[] client_msg_hash, ArrayList<Object> message) throws Exception {
		
		byte[] group_msg_hash = getMessageHMAC(message);
		
		if(MessageDigest.isEqual(group_msg_hash, client_msg_hash)) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public static byte[] concatenateArrays(byte[] arr1, byte[] arr2) {
		byte[] arr3 = new byte[arr1.length + arr2.length];
		for (int i = 0; i < arr1.length; i++) {
			arr3[i] = arr1[i];
		}
		for (int i = 0; i < arr2.length; i++) {
			arr3[i + arr1.length] = arr2[i];
		}
		return arr3;
	}
	
	public byte[] getMessageHMAC(ArrayList<Object> message) throws Exception {
		byte[] hmac = null;
		//byte[] content = concatenateArrays(message.toString().getBytes(), iv);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(message);
		oos.flush();
		byte[] content = bos.toByteArray();
		
		try {		
			Mac mac = Mac.getInstance("HmacSHA256");
			mac.init(integrity_key);
			hmac = mac.doFinal(content);
			//System.out.println("content is " +Arrays.toString(content));
			//System.out.println("hmac(m) is " +Arrays.toString(hmac));
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return hmac;
	}
	
	private static PublicKey getPublicKeyFromCA(String fileServerName, String CA_Address, int CA_PORT) {
		PublicKey pk = null;
		
		// connected to CA server
		CAclient cc = new CAclient();
		cc.connect(CA_Address, CA_PORT);
		
		try {
			System.out.printf("Attempt to get %s's key \n", fileServerName);
			pk = cc.getPublicKeyFromCA(fileServerName);		
			System.out.println("@getPublicKeyFromCA");
			cc.disconnect();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return pk;
	}
	
	public void Disconnect(){
		try
		{
			Envelope message = new Envelope("DISCONNECT");
			Envelope m = new Envelope("message");
			sequenceNumber = sequenceNumber+1;
			m.addObject(sequenceNumber);
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);	
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
		
	}
	
	public boolean delete(String filename, SignedObject token) {
		String remotePath;
		if (filename.charAt(0) == '/') {
			remotePath = filename.substring(1);
		} else {
			remotePath = filename;
		}
		
		try {
			Envelope env = new Envelope("DELETEF"); // Success
			Envelope m = new Envelope("message");
			m.addObject(remotePath);
			m.addObject(token);
			sequenceNumber = sequenceNumber+1;
			m.addObject(sequenceNumber);
			
			env.addObject(m);
			env.addObject(getMessageHMAC(m.getObjContents()));
			
			SealedObject sealed_msg = new SealedObject(env, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			env = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			

			if (env.getMessage().compareTo("OK") == 0) {
				ArrayList<Object> temp = null;
				temp = env.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) env.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("File %s deleted successfully\n", filename);
								return true;
							}
						}
					}
				}
				
				
				
			} else {
				
				ArrayList<Object> temp = null;
				temp = env.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) env.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("Error deleting file %s (%s)\n", filename, env.getMessage());
								return false;
							}
						}
					}
				}
				
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return true;
	}

	public boolean download(String sourceFile, String destFile, SignedObject token) throws Exception {
		if (sourceFile.charAt(0) == '/') {
			sourceFile = sourceFile.substring(1);
		}

		File file = new File(destFile);
		try {

			if (!file.exists()) {
				file.createNewFile();
				FileOutputStream fos = new FileOutputStream(file);

				Envelope env = new Envelope("DOWNLOADF"); // Success
				Envelope m = new Envelope("message");
				m.addObject(sourceFile);
				m.addObject(token);
				sequenceNumber = sequenceNumber+1;
				m.addObject(sequenceNumber);
				env.addObject(m);
				env.addObject(getMessageHMAC(m.getObjContents()));
				SealedObject sealed_msg = new SealedObject(env, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				SealedObject encrypt_msg = (SealedObject)input.readObject();
				env = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
				

				while (env.getMessage().compareTo("CHUNK") == 0) {
					fos.write((byte[]) env.getObjContents().get(0), 0, (Integer) env.getObjContents().get(1));
					System.out.printf(".");
					env = new Envelope("DOWNLOADF"); // Success
					SealedObject sealed_msg_1 = new SealedObject(env, client_cipher_encrypt);
					output.writeObject(sealed_msg_1);
				
					SealedObject encrypt_msg_1 = (SealedObject)input.readObject();
					env = (Envelope)encrypt_msg_1.getObject(client_cipher_decrypt);
					
				}
				fos.close();

				if (env.getMessage().compareTo("EOF") == 0) {
					ArrayList<Object> temp = null;
					temp = env.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) env.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq > (sequenceNumber)) {
								sequenceNumber = response_sq + 1;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									fos.close();
									System.out.printf("\nTransfer successful file %s\n", sourceFile);
									env = new Envelope("OK"); // Success
									Envelope m1 = new Envelope("message");
									sequenceNumber = sequenceNumber+1;
									m1.addObject(sequenceNumber);
									env.addObject(m1);
									env.addObject(getMessageHMAC(m1.getObjContents()));
									SealedObject sealed_msg_2 = new SealedObject(env, client_cipher_encrypt);
									output.writeObject(sealed_msg_2);
								}
							}
						}
					}
					
					
				} else {
					sequenceNumber++;
					System.out.printf("Error reading file %s (%s)\n", sourceFile, env.getMessage());
					file.delete();
					return false;
				}
			}

			else {
				sequenceNumber++;
				System.out.printf("Error couldn't create file %s\n", destFile);
				return false;
			}

		} catch (IOException e1) {

			System.out.printf("Error couldn't create file %s\n", destFile);
			return false;

		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	@SuppressWarnings("unchecked")
	public List<String> listFiles(SignedObject token) {
		try {
			Envelope message = null, e = null;
			// Tell the server to return the member list
			message = new Envelope("LFILES");
			Envelope m = new Envelope("message");
			m.addObject(token); // Add requester's token
			sequenceNumber = sequenceNumber+1;
			m.addObject(sequenceNumber);
			
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg_1 = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg_1);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			e = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			// If server indicates success, return the member list
			if (e.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = e.getObjContents();
				System.out.println("0");
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) e.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])e.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						
						int response_sq = (int)msg.getObjContents().get(1);
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							System.out.println("Listed Files:");
							int count = 1;
							for (ShareFile file : (List<ShareFile>) msg.getObjContents().get(0)) {
								System.out.println("File" + count++ + ": " + file.getPath());
							}
							return (List<String>) msg.getObjContents().get(0); // This cast creates compiler warnings. Sorry.
						}
						
					}
				}
			}else {
				ArrayList<Object> temp = null;
				temp = e.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) e.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])e.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.println("Failed to list files.");
								return null;
							}
						}
					}
				}
			}
				
			return null;

		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);

			return null;
		}
	}

	public boolean upload(String sourceFile, String destFile, String group, SignedObject token, int n, byte[] randIV) {

		if (destFile.charAt(0) != '/') {
			destFile = "/" + destFile;
		}

		try {

			Envelope message = null, env = null;
			// Tell the server to return the member list
			message = new Envelope("UPLOADF");
			Envelope m = new Envelope("message");
			m.addObject(destFile);
			System.out.println(destFile + ";" + group + ";" + n);
			m.addObject(group);
			m.addObject(token); // Add requester's token
			m.addObject(n);
			m.addObject(randIV);
			sequenceNumber = sequenceNumber+1;
			m.addObject(sequenceNumber);
			
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			SealedObject sealed_msg_1 = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg_1);
			
			FileInputStream fis = new FileInputStream(sourceFile);

			SealedObject encrypt_msg = (SealedObject)input.readObject();
			env = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);

			// If server indicates success, return the member list
			if (env.getMessage().equals("READY")) {
				ArrayList<Object> temp = null;
				temp = env.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) env.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("Meta data upload successful\n" + sequenceNumber);
							}
						}
					}
				}

			} else {
				sequenceNumber = sequenceNumber+1;
				System.out.printf("Upload failed: %s\n", env.getMessage());
				return false;
			}

			do {
				byte[] buf = new byte[4096];
				if (env.getMessage().compareTo("READY") != 0) {
					System.out.printf("Server error: %s\n", env.getMessage());
					return false;
				}
				message = new Envelope("CHUNK");
				int N = fis.read(buf); // can throw an IOException
				if (N > 0) {
					System.out.printf(".");
				} else if (N < 0) {
					System.out.println("Read error");
					return false;
				}
				
				message.addObject(buf);
				message.addObject(new Integer(N));
				
				sequenceNumber = sequenceNumber+1;
				SealedObject sealed_msg_2 = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg_2);
				
				SealedObject encrypt_msg_1 = (SealedObject)input.readObject();
				env = (Envelope)encrypt_msg_1.getObject(client_cipher_decrypt);


			} while (fis.available() > 0);

			// If server indicates success, return the member list
			if (env.getMessage().compareTo("READY") == 0) {

				message = new Envelope("EOF");
				Envelope m1 = new Envelope("message");
				sequenceNumber = sequenceNumber+1;
				m1.addObject(sequenceNumber);
				message.addObject(m1);
				message.addObject(getMessageHMAC(m1.getObjContents()));
				
				SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
				output.writeObject(sealed_msg);
				
				SealedObject encrypt_msg_1 = (SealedObject)input.readObject();
				env = (Envelope)encrypt_msg_1.getObject(client_cipher_decrypt);

				if (env.getMessage().compareTo("OK") == 0) {
					ArrayList<Object> temp = null;
					temp = env.getObjContents();
					
					if(temp.size() == 2)
					{
						Envelope msg = (Envelope) env.getObjContents().get(0);
						byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
						
						if(msg.getObjContents().size() == 1) {
							int response_sq = (int)msg.getObjContents().get(0);
							
							if(response_sq > (sequenceNumber)) {
								sequenceNumber = response_sq;
								if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
									System.out.printf("\nFile data upload successful\n sq_num is"+sequenceNumber);
								}
							}
						}
					}
					
					
				} else {
					sequenceNumber = sequenceNumber+1;
					System.out.printf("\nUpload failed: %s\n", env.getMessage());
					return false;
				}

			} else {
				sequenceNumber = sequenceNumber+1;
				System.out.printf("Upload failed: %s\n", env.getMessage());
				return false;
			}

		} catch (Exception e1) {
			System.err.println("Error: " + e1.getMessage());
			e1.printStackTrace(System.err);
			return false;
		}
		return true;
	}//upload
	
	public String getFileGroup(String file, SignedObject token) {
		String groupname = null;
		
		try {

			Envelope message = null, env = null;
			// Tell the server to return the member list
			message = new Envelope("GETFILEGROUP");
			Envelope m = new Envelope("message");
			m.addObject(file);
			m.addObject(token); // Add requester's token
			sequenceNumber = sequenceNumber+1;
			m.addObject(sequenceNumber);
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			env = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(env.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = env.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) env.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						groupname = (String)msg.getObjContents().get(0);
						
						int response_sq = (int)msg.getObjContents().get(1);
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.printf("File: %s, is belong to group: %s \n", file, groupname);
								return groupname;
							}
						}
					}
				}
				
				
			} else {
			
				ArrayList<Object> temp = null;
				temp = env.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) env.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.println("Fail to get file group");
								return null;
							}
						}
					}
				}
			
				
			}
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return groupname;
	}
	
	public int getFileN(String file, SignedObject token) {
		int n = -1;
		
		try {

			Envelope message = null, env = null;
			// Tell the server to return the member list
			message = new Envelope("GETFILEN");
			Envelope m = new Envelope("message");
			m.addObject(file);
			m.addObject(token); // Add requester's token
			sequenceNumber = sequenceNumber+1;
			m.addObject(sequenceNumber);
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			env = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(env.getMessage().equals("OK")) {
				
				ArrayList<Object> temp = null;
				temp = env.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) env.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						n = (int)msg.getObjContents().get(0);
						
						int response_sq = (int)msg.getObjContents().get(1);
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								
								System.out.printf("File: %s, has property n: %d \n", file, n);
							}
						}
					}
				}
				
				
			} else {
				ArrayList<Object> temp = null;
				temp = env.getObjContents();
				
				if(temp.size() == 2)
				{
					Envelope msg = (Envelope) env.getObjContents().get(0);
					byte[] group_rsp_hash = (byte[])env.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 1) {
						int response_sq = (int)msg.getObjContents().get(0);
						
						if(response_sq > (sequenceNumber)) {
							sequenceNumber = response_sq;
							if(checkHMAC(group_rsp_hash, msg.getObjContents())) {
								System.out.println("Fail to get file group");
								
							}
						}
					}
				}
				
				
			}
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return n;
	}

	public byte[] getFileIV(String file, SignedObject token) {
		byte[] IV = null;
		try {
		
			Envelope message = null, response = null;
			// Tell the server to return the member list
			message = new Envelope("GETFILEIV");
			Envelope m = new Envelope("message");
			sequenceNumber ++;
			
			m.addObject(file);
			m.addObject(token); // Add requester's token
			m.addObject(sequenceNumber);
			
			message.addObject(m);
			message.addObject(getMessageHMAC(m.getObjContents()));
			
			SealedObject sealed_msg = new SealedObject(message, client_cipher_encrypt);
			System.out.println("write");
			output.writeObject(sealed_msg);
			
			SealedObject encrypt_msg = (SealedObject)input.readObject();
			response = (Envelope)encrypt_msg.getObject(client_cipher_decrypt);
			
			if(response.getMessage().equals("OK")) {
				ArrayList<Object> temp = null;
				temp = response.getObjContents();
				
				if(temp.size() == 2) {//m, HMAC
					Envelope msg = (Envelope) response.getObjContents().get(0);	//m
					byte[] fileServer_hash = (byte[])response.getObjContents().get(1);
					
					if(msg.getObjContents().size() == 2) {
						if((int)msg.getObjContents().get(1)>sequenceNumber) {
							if(checkHMAC(fileServer_hash, msg.getObjContents())) {
								
								IV = (byte[])msg.getObjContents().get(0);
								System.out.printf("Get file IV \n");
								
								sequenceNumber ++; //sequenceNumber now equal FileServer side seqN
							}else {
								System.out.println("HMAC doesn't match");
								
							}
							
						} else {
							System.out.printf("\nsequenceNumber doesn't match__\n");
							
						}//end check sequenceNumber & check HMAC
					}//check m size
				}
				
			} else {
				System.out.println("Fail to get file group");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return IV;
	}
	

	
}
