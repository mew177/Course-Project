import java.io.Serializable;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;

public class Token implements UserToken, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5913312437350065L;
	private String Issuer;
	private String Subject;
	private Long timestamp;
	private PublicKey fileServerPublicKey;
	private List<String> GroupList;
	
	// Token Constructor
	public Token(String Issuer, String Subject, List<String> GroupList, PublicKey fileServerPublicKey) {
		this.Issuer = Issuer;
		this.Subject = Subject;
		this.GroupList = GroupList;
		this.fileServerPublicKey = fileServerPublicKey;
		this.timestamp = System.currentTimeMillis();
	}
	
	public ArrayList<Object> getObjContents(){
		ArrayList<Object> objs = new ArrayList<Object>();
		objs.add(Issuer);
		objs.add(Subject);
		objs.add(GroupList);
		objs.add(fileServerPublicKey);
		objs.add(timestamp);
		return objs;
	}
	
	@Override
	public String getIssuer() {
		// get Issuer
		return Issuer;
	}
	
	public PublicKey getFileServerKey() {
		// get Issuer
		return fileServerPublicKey;
	}

	@Override
	public String getSubject() {
		// get Subject
		return Subject;
	}

	@Override
	public List<String> getGroups() {
		// get GroupList
		return GroupList;
	}
	
	public Long getTimestamps() {
		return timestamp;
	}

}
