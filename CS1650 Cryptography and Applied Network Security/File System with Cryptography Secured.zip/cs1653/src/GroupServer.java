import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.io.*;
import java.util.*;



public class GroupServer extends Server {

	public static final int SERVER_PORT = 8765;
	public static final int CA_PORT = 9999;
	public static String CA_Address;
	public UserList userList;
	public GroupList groupList;
	private static KeyPair GroupServerKeyPair = null;
	private byte[] iv;

	public GroupServer() {
		super(SERVER_PORT, "ALPHA");
		CA_Address = "127.0.0.1";
	}

	public GroupServer(int _port, String CA) {
		super(_port, "ALPHA");
		CA_Address = CA;
	}

	public void start() {
		// Overwrote server.start() because if no user file exists, initial admin account needs to be created

		String userFile = "UserList.bin";
		String groupFile = "GroupList.bin";
		Scanner console = new Scanner(System.in);
		ObjectInputStream userStream;
		ObjectInputStream groupStream;

		//This runs a thread that saves the lists on program exit
		Runtime runtime = Runtime.getRuntime();
		runtime.addShutdownHook(new ShutDownListener(this));

		//Open user file to get user list
		try
		{
			FileInputStream fis = new FileInputStream(userFile);
			userStream = new ObjectInputStream(fis);
			userList = (UserList)userStream.readObject();
			
			fis = new FileInputStream(groupFile);
			groupStream = new ObjectInputStream(fis);
			groupList = (GroupList)groupStream.readObject();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("UserList File Does Not Exist. Creating UserList...");
			System.out.println("No users currently exist. Your account will be the administrator.");
			System.out.print("Enter your username: ");
			String username = console.next();

			//Create a new list, add current user to the ADMIN group. They now own the ADMIN group.
			userList = new UserList();
			userList.addUser(username);
			userList.addGroup(username, "ADMIN");
			userList.addOwnership(username, "ADMIN");
			
			// Create a new list, add ADMIN group
			groupList = new GroupList();
			groupList.addGroup("ADMIN");
			
			SaveFile();
			LoadFile();
		}
		catch(IOException e)
		{
			System.out.println("Error reading from UserList file");
			System.exit(-1);
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("Error reading from UserList file");
			System.exit(-1);
		}

		//Autosave Daemon. Saves lists every 5 minutes
		AutoSave aSave = new AutoSave(this);
		aSave.setDaemon(true);
		aSave.start();

		//This block listens for connections and creates threads on new connections
		try
		{

			final ServerSocket serverSock = new ServerSocket(port);
			System.out.println("*** Server Start ***");
			
			GroupServerKeyPair = getKeyPair();
			addPublicKeyToCA();	
			
			
			Socket sock = null;
			GroupThread thread = null;

			while(true)
			{
				sock = serverSock.accept();
				thread = new GroupThread(sock, this, GroupServerKeyPair);
				thread.start();
			}
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}

	}
	
	public boolean SaveFile() 
	{
		ObjectOutputStream gStream;
		ObjectOutputStream uStream;
		
		try 
		{
			uStream = new ObjectOutputStream(new FileOutputStream("UserList.bin"));
			uStream.writeObject(this.userList);
			gStream = new ObjectOutputStream(new FileOutputStream("GroupList.bin"));
			gStream.writeObject(this.groupList);
			gStream.close();
			uStream.close();
			return true;
			
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
		
		return false;
		
	}
	
	public boolean LoadFile() 
	{
		ObjectInputStream uStream;
		ObjectInputStream gStream;
		
		try 
		{
			uStream = new ObjectInputStream(new FileInputStream("UserList.bin"));
			this.userList = (UserList)uStream.readObject();
			
			gStream = new ObjectInputStream(new FileInputStream("GroupList.bin"));
			this.groupList = (GroupList)gStream.readObject();
			gStream.close();
			uStream.close();
			return true;
			
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
		
		return false;
		
	}
	
	private static KeyPair getKeyPair() throws NoSuchAlgorithmException {
		KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
	    generator.initialize(1024, new SecureRandom());
	    KeyPair pair = generator.generateKeyPair();
	    
		return pair;
	}
	
	private static void addPublicKeyToCA() throws IOException {
		
		// connected to CA
		CAclient cc = new CAclient();
		cc.connect(CA_Address, CA_PORT);
		
		// add public key to envelope
		Envelope post = new Envelope("POSTG");
		post.addObject(GroupServerKeyPair.getPublic());
		System.out.println("Sending Key to CA");
		
		// send envelope
		cc.output.writeObject(post);
		System.out.println("Public Key Posted");
		
		cc.disconnect();

	}
	
	

}

//This thread saves the user list
class ShutDownListener extends Thread
{
	public GroupServer my_gs;

	public ShutDownListener (GroupServer _gs) {
		my_gs = _gs;
	}

	public void run()
	{
		System.out.println("Shutting down server");
		ObjectOutputStream outStream;
		try
		{
			outStream = new ObjectOutputStream(new FileOutputStream("UserList.bin"));
			outStream.writeObject(my_gs.userList);
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
	}
}

class AutoSave extends Thread
{
	public GroupServer my_gs;

	public AutoSave (GroupServer _gs) {
		my_gs = _gs;
	}

	public void run()
	{
		do
		{
			try
			{
				Thread.sleep(300000); //Save group and user lists every 5 minutes
				System.out.println("Autosave group and user lists...");
				ObjectOutputStream outStream;
				try
				{
					outStream = new ObjectOutputStream(new FileOutputStream("UserList.bin"));
					outStream.writeObject(my_gs.userList);
					outStream = new ObjectOutputStream(new FileOutputStream("GroupList.bin"));
					outStream.writeObject(my_gs.groupList);
				}
				catch(Exception e)
				{
					System.err.println("Error: " + e.getMessage());
					e.printStackTrace(System.err);
				}

			}
			catch(Exception e)
			{
				System.out.println("Autosave Interrupted");
			}
		} while(true);
	}
}

