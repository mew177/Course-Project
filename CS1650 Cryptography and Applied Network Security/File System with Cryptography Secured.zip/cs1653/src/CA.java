
import java.io.File;
import java.net.ServerSocket;
import java.net.Socket;

public class CA extends Server{
	
	public static final int SERVER_PORT = 9999;
	
	public CA() {
		super(SERVER_PORT, "CA");
	}

	public CA(int port) {
		super(port, "CA");		
	}

	@Override
	void start() {		
		
		Socket sock = null;
		Thread thread = null;
		
		try
		{			
			final ServerSocket serverSock = new ServerSocket(port);
			System.out.printf("%s up and running\n", this.getClass().getName());
					
			createDir();
			
			while(true)
			{
				sock = serverSock.accept();
				thread = new CAThread(sock, this);
				thread.start();
				
			}
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
		
	}
	
	private static void createDir() {
		File file = new File("CA");
		if(!file.exists()) {
			file.mkdirs();
		}
		
		System.err.println("CA ready to be connected...");
	}
		
	
	public static void main(String args[]) {
		
		if (args.length > 0) {
			try {
				CA server = new CA(Integer.parseInt(args[0]));
				server.start();
			}
			catch (NumberFormatException e) {
				System.out.printf("Enter a valid port number or pass no arguments to use the default port (%d)\n", FileServer.SERVER_PORT);
			}
		}
		else {
			CA server = new CA();
			server.start();
		}
		
		
	}
	
}




