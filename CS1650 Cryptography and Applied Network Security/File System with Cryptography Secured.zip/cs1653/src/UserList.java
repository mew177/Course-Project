/* This list represents the users on the server */
import java.io.Serializable;
import java.security.MessageDigest;
import java.util.*;

	public class UserList implements java.io.Serializable {
	
		/**
		 * 
		 */
		private static final long serialVersionUID = 7600343803563417992L;
		private Hashtable<String, User> list = new Hashtable<String, User>();
		private Hashtable<String, Profile> profileList = new Hashtable<String, Profile>();
		
		public synchronized void addUser(String username)
		{
			// create a user and add user to user list
			User newUser = new User();
			Profile newProfile = new Profile();
			list.put(username, newUser);
			profileList.put(username, newProfile);
			System.out.printf("User %s create successfully! \n", username);
		}
		
		public synchronized void deleteUser(String username)
		{
			list.remove(username);
			System.out.printf("User %s removed successfully! \n", username);
		}
		
		public synchronized boolean checkUser(String username)
		{
			if(list.containsKey(username))
			{
				System.out.printf("User %s is in user list! \n", username);
				return true;
			}
			else
			{
				System.out.printf("User %s is not in user list! \n", username);
				return false;
			}
		}
		
		public synchronized ArrayList<String> getUserGroups(String username)
		{
			System.out.printf("Sending user group message to client \n");
			return list.get(username).getGroups();
		}
		
		public synchronized byte[] getUserPassword(String username)
		{
			return list.get(username).getPassword();
		}
		
		
		public synchronized ArrayList<String> getUserOwnership(String username)
		{
			System.out.printf("Sending user ownership to client \n");
			return list.get(username).getOwnership();
		}
		
		public synchronized void addGroup(String user, String groupname)
		{
			list.get(user).addGroup(groupname);
			System.out.printf("User %s added to group %s successfully! \n", user, groupname);
		}
		
		public synchronized void removeGroup(String user, String groupname)
		{
			list.get(user).removeGroup(groupname);
			System.out.printf("User %s removed to group %s successfully! \n", user, groupname);
		}
		
		public synchronized void addOwnership(String user, String groupname)
		{
			list.get(user).addOwnership(groupname);
			System.out.printf("User %s gained the ownership of group %s! \n", user, groupname);
		}
		
		public synchronized void removeOwnership(String user, String groupname)
		{
			list.get(user).removeOwnership(groupname);
			System.out.printf("User %s lost the ownership of group %s! \n", user, groupname);
		}
		
		public synchronized User getUser(String user) {
			return list.get(user);
		}
		
		public synchronized boolean checkLock(String user) {
			return list.get(user).checkLock();
		}
		
		public synchronized ArrayList<String> getProfile(String requestor, String user) {		
			return profileList.get(user).getProfile(requestor);
		}
		
		public synchronized void addFriend(String user, String friend) {
			profileList.get(user).addFriend(friend);
		}
		
		public synchronized void removeFriend(String user, String friend) {
			profileList.get(user).removeFriend(friend);
		}

		public synchronized void setPrivacy(String user, int level) {
			profileList.get(user).setPrivacy(level);
		}
		
		public synchronized void setProfile(String user, String firstname, String lastname, int age, String content) {
			profileList.get(user).SetProfile(firstname, lastname, age, content);
		}
	
	class User implements java.io.Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = -6699986336399821598L;
		private ArrayList<String> groups;
		private ArrayList<String> ownership;
		private byte[] password;
		private boolean locked;
		private Long lockTime;
		private int tried;
		
		public User()
		{
			groups = new ArrayList<String>();
			ownership = new ArrayList<String>();
			password = generatePassword();
			locked = false;
			lockTime = null;
			tried = 0;
		}
		
		public void lockUser() {
			locked = true;
			lockTime = System.currentTimeMillis();
		}
		
		public void releaseUser() {
			tried = 0;
			locked = false;
			lockTime = null;
		}
		
		public boolean checkLock() {
		
			// already locked for 1 min
			if(locked) {
				System.out.println("locked since: " + this.getLockTime());
				System.out.println("time now: " + System.currentTimeMillis());
				if(System.currentTimeMillis() - this.getLockTime() > 60000) {
					releaseUser();
				}
			} else {
				// tried to login
				tried++;			
				if (tried >= 3) lockUser();		
			}
			
			System.out.printf("locked: %b, tried: %d \n", locked, tried);
			
			return locked;
		}
		
		public Long getLockTime() {
			return lockTime;
		}
		
		public String getRemainLockTime() {
			String remain = "0";
			
			Long start = this.getLockTime();
			Long end = System.currentTimeMillis();
			
			remain = String.valueOf( 60 - ((end - start) / 1000) );
			
			return remain;
		}
		
		public ArrayList<String> getGroups()
		{
			return groups;
		}
		
		public ArrayList<String> getOwnership()
		{
			return ownership;
		}
		
		public byte[] getPassword() {
			return password;
		}
		
		public void addGroup(String group)
		{
			groups.add(group);
		}
		
		public void removeGroup(String group)
		{
			if(!groups.isEmpty())
			{
				if(groups.contains(group))
				{
					groups.remove(groups.indexOf(group));
				}
			}
		}
		
		public void addOwnership(String group)
		{
			ownership.add(group);
		}
		
		public void removeOwnership(String group)
		{
			if(!ownership.isEmpty())
			{
				if(ownership.contains(group))
				{
					ownership.remove(ownership.indexOf(group));
				}
			}
		}
		
		private byte[] generatePassword(){
			
			try {
				final int PASSWORD_LEN = 10;
				
				String elements = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
				StringBuilder sb = new StringBuilder();
				Random random = new Random(System.currentTimeMillis());
				for(int k = 0; k < PASSWORD_LEN; k++) {
					sb.append(elements.charAt(random.nextInt(elements.length())));
				}
				
				System.out.println("Your password: " + sb.toString());
				
				MessageDigest md = MessageDigest.getInstance("SHA-256");
				
				// For actual USE, every user has random 10 characters password
		   		//md.update(sb.toString().getBytes("UTF-8"));
				
		   		// FOR DEBUGGING USE, every user has password "123"
				md.update("123".toString().getBytes("UTF-8"));
				
		   		byte[] hashed_password = md.digest();
		   		System.out.println("The password has been hashed: " + hashed_password);
		   		
				return hashed_password;
			}catch(Exception e){
				System.err.println("Error: hashing the password");
				e.printStackTrace(System.err);
				return null;
			}
			
		}	
		
	}
	
	class Profile implements Serializable {
		
		// 0 private; 1 for public
		private int privacy;
		private String firstname;
		private String lastname;
		private int age;
		private ArrayList<String> friendList;
		private String content;
		
		public Profile() {
			privacy = 0;
			firstname = "";
			lastname = "";
			age = 0;
			content = "Welcome to my profile";					
		}
		
		public void setPrivacy(int privacy) {
			this.privacy = privacy;
			System.out.println("Set privacy argument to " + privacy);
		}
		
		public ArrayList<String> getProfile(String requestor) {
			ArrayList<String> profile = new ArrayList<>();
			
			/*
			if(privacy == 2) {
				profile.add(firstname);
				profile.add(lastname);
				profile.add(String.valueOf(age));
				profile.add(content);
			} else if (privacy == 1) {
				if(checkFriendShip(requestor)) {
					profile.add(firstname);
					profile.add(lastname);
					profile.add(String.valueOf(age));
					profile.add(content);
				} else {
					profile.add("Secret");
					profile.add("Secret");
					profile.add("Secret");
					profile.add("Secret");
				}				
			} else {
				profile.add("Secret");
				profile.add("Secret");
				profile.add("Secret");
				profile.add("Secret");
			}
			*/
			
			if(privacy == 1) {
				profile.add(firstname);
				profile.add(lastname);
				profile.add(String.valueOf(age));
				profile.add(content);
			} else {
				profile.add("Secret");
				profile.add("Secret");
				profile.add("Secret");
				profile.add("Secret");
			}
					
			return profile;			
		}
		
		public boolean checkFriendShip(String user) {
			if(friendList.contains(user)) {
				return true;
			} else {
				return false;
			}
		}
		
		public boolean addFriend(String user) {
			if(!friendList.contains(user)) {
				friendList.add(user);
				return true;
			}
			return false;
		}
		
		public void setProfile(String firstname, String lastname, int age, String content) {
			this.firstname = firstname;
			this.lastname = lastname;
			this.age = age;
			this.content = content;
		}
		
		public boolean removeFriend(String user) {
			if(friendList.contains(user)) {
				friendList.remove(user);
				return true;
			}
			return false;
		}
		
		public void SetProfile(String firstname, String lastname, int age, String content) {
			this.firstname = firstname;
			this.lastname = lastname;
			this.age = age;
			this.content = content;
			System.out.println("Profile Updated");
		}
		
		public ArrayList<String> getFriendList() {
			return friendList;
		}
	}
	
}	
