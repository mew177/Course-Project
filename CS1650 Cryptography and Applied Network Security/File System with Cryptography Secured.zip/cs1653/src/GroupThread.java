
/* This thread does all the work. It communicates with the client through Envelopes.
 * 
 */
import java.lang.Thread;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignedObject;
import java.io.*;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


//import javax.xml.bind.DatatypeConverter;

public class GroupThread extends Thread {
	private final Socket socket;
	private GroupServer my_gs;

	static final String ANSI_RESET = "\u001B[0m";
	static final String ANSI_RED = "\u001B[31m";
	final int PASSWORD_LEN = 10;

	private SecretKey symmetricKey;
	private SecretKey integrity_key;
	private String group_server_challenge;
	private Cipher gs_cipher_decrypt;
	private Cipher gs_cipher_encrypt;
	private boolean no_more_raw_msg = false;
	private KeyPair GroupServerKeypair = null;
	private int sequenceNumber;
	private final byte[] iv = {122, 51, 6, 17, 79, 41, 34, 18, -125, -15, 108, 63, -41, 125, 67, 34};

	public GroupThread(Socket _socket, GroupServer _gs, KeyPair GroupServerKeypair) throws NoSuchAlgorithmException, IOException {
		socket = _socket;
		my_gs = _gs;
		this.GroupServerKeypair = GroupServerKeypair;
	}


	public void run() {
		boolean proceed = true;

		try {
			// Announces connection and opens object streams
			System.out.println("*** New connection from " + socket.getInetAddress() + ":" + socket.getPort() + "***");
			final ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
			final ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());

			do {

				if (!no_more_raw_msg) {
					Envelope message = (Envelope) input.readObject();
					System.out.println("Request received: " + message.getMessage());
					Envelope response;

					// Load latest file
					my_gs.LoadFile();

					// -------------------------------------User
					// Login--------------------------------------------------------

					if (message.getMessage().equals("Generate_Shared_Key")) {
						boolean created = false;

						if (message.getObjContents().size() < 2) {
							response = new Envelope("FAIL");
						} else {
							response = new Envelope("FAIL");

							if (message.getObjContents().get(0) != null) {
								if (message.getObjContents().get(1) != null) {
									String username = (String) message.getObjContents().get(0); // Extract the username
									PublicKey clientPublicKey = (PublicKey) message.getObjContents().get(1); // Extract
																												// client's
																												// key
									KeyPair serverKeyPair = DiffieHellman.genKeyPair();
									KeyAgreement keyAgreement = DiffieHellman.genKeyAgreement(serverKeyPair);
									symmetricKey = DiffieHellman.generateSecretKey(clientPublicKey, keyAgreement);

									Random rand = new Random();
									group_server_challenge = rand.toString();
									gs_cipher_encrypt = Cipher.getInstance("AES");
									gs_cipher_encrypt.init(Cipher.ENCRYPT_MODE, symmetricKey);
									gs_cipher_decrypt = Cipher.getInstance("AES");
									gs_cipher_decrypt.init(Cipher.DECRYPT_MODE, symmetricKey);
									
									byte[] cipherText = gs_cipher_encrypt.doFinal(group_server_challenge.getBytes("UTF8"));
									
									Signature signature = Signature.getInstance("SHA1withRSA");
									SignedObject signedSymmetricPublic = new SignedObject(serverKeyPair.getPublic(), GroupServerKeypair.getPrivate(), signature);

									SignedObject signedChallenge = new SignedObject(cipherText, GroupServerKeypair.getPrivate(), signature);

									System.out.println("group symmetric key is "
											+ Base64.getEncoder().encodeToString(symmetricKey.getEncoded()));
									System.out.println("group server challenge has been generated");
									response = new Envelope("OK"); // Success
									response.addObject(signedSymmetricPublic);
									response.addObject(signedChallenge);
									no_more_raw_msg = true;
								}
							}
						}

						output.writeObject(response);
					}
					
				} else {
					
					SealedObject encrypt_msg = (SealedObject) input.readObject();
					Envelope message = (Envelope) encrypt_msg.getObject(gs_cipher_decrypt);
					Envelope response;
					
					if (message.getMessage().equals("User_Password_Check")) {

						if (message.getObjContents().size() < 4) {
							response = new Envelope("FAIL");
						} else {
							response = new Envelope("FAIL");

							if (message.getObjContents().get(0) != null) {
								if (message.getObjContents().get(1) != null) {
									if (message.getObjContents().get(2) != null) {
										if (message.getObjContents().get(3) != null) {
									
											String username = (String) message.getObjContents().get(0);
											byte[] hashPassword = (byte[]) message.getObjContents().get(1);
											String s = (String)message.getObjContents().get(2);
											int msg_sq = (int)message.getObjContents().get(3);
											
											if (s.equals(group_server_challenge)) {
												System.out.println("group server challenge is matched");											
												if (my_gs.userList.checkUser(username)) {
													// if user is not locked
													sequenceNumber = msg_sq+1;
													if(!my_gs.userList.getUser(username).checkLock()) {
														
														if (Arrays.equals(hashPassword, my_gs.userList.getUserPassword(username))) {
															System.out.println("Password is matched");
															my_gs.userList.getUser(username).releaseUser();
															System.out.println("group server set sequence number initially as " + sequenceNumber);
															
															String temp = symmetricKey.toString() + "Integrity";
															try {
																MessageDigest md = MessageDigest.getInstance("SHA-256");
																md.update(temp.getBytes("UTF-8"));
																byte[] integrate_hash = md.digest();
																integrity_key = new SecretKeySpec(integrate_hash, 0, integrate_hash.length, "AES");
																System.out.println("group server's integrate key is " 
																		+ Base64.getEncoder().encodeToString(integrity_key.getEncoded()));
																response = new Envelope("OK"); // Success
																response.addObject(sequenceNumber);
																
															} catch (Exception e) {
																e.printStackTrace();
																System.out.println("group server generate integrity key fail");
															}
															
														} else {
															
															System.out.println("User has not be created yet");
															response = new Envelope("FAIL"); // Success
														
														}
													} else {
														// if user is locked
														
														System.out.println("Locked Account");
														response = new Envelope("LOCKED");
														
														System.out.println("Remain time: " + my_gs.userList.getUser(username).getRemainLockTime());
													}
												} 
											}
										}
									}
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}

					// -------------------------------------Group Server
					// Function----------------------------------------------

					else if (message.getMessage().equals("GET"))// Client wants a token
					{
						if (message.getObjContents().size() < 2) {
							response = new Envelope("FAIL");
						} else {
							response = new Envelope("FAIL");
							Token token = null;
							Envelope m = new Envelope("message");
							
							if (message.getObjContents().get(0) != null) {
								if (message.getObjContents().get(1) != null) {
									Envelope msg = (Envelope) message.getObjContents().get(0);
									byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
									
									if (msg.getObjContents().get(0) != null) {
										if (msg.getObjContents().get(1) != null) {
											if (msg.getObjContents().get(2) != null) {
									
												String username = (String) msg.getObjContents().get(0); // Get the username
												PublicKey fs_public = (PublicKey) msg.getObjContents().get(1);
												int msg_sq = (int)msg.getObjContents().get(2);
												
												if(msg_sq > (sequenceNumber)) {
												
													if(checkHMAC(client_msg_hash, msg.getObjContents())) {
														System.out.println("hash message match");
														token = createToken(username, fs_public); // Create a token
														response = new Envelope("OK");
														m.addObject(sign(token,  GroupServerKeypair.getPrivate()));
													}
													
													sequenceNumber = sequenceNumber+2;
													m.addObject(sequenceNumber);
													response.addObject(m);
													response.addObject(getMessageHMAC(m.getObjContents()));	
												}
											}
										}
									}
								}
							}
						}
						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
						
					} 
					else if (message.getMessage().equals("CUSER")) {
						response = new Envelope("FAIL");
						Envelope m = new Envelope("message");
						
							if (message.getObjContents().get(0) != null) {
								if (message.getObjContents().get(1) != null) {
									Envelope msg = (Envelope) message.getObjContents().get(0);
									byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
									
									if (msg.getObjContents().get(0) != null) {
										if (msg.getObjContents().get(1) != null) {
											if (msg.getObjContents().get(2) != null) {
												String username = (String) msg.getObjContents().get(0); // Extract the username
												SignedObject signedToken = (SignedObject) msg.getObjContents().get(1); // Extract
												int msg_sq = (int) msg.getObjContents().get(2);
													
												if(msg_sq > (sequenceNumber)) {
													if (verify(signedToken, GroupServerKeypair.getPublic())) {
														if(checkHMAC(client_msg_hash, msg.getObjContents())) {
															Token token = getUnsignedToken(signedToken);
															if (createUser(username, token)) {
																response = new Envelope("OK"); // Success
																
															}
														}
													}
													sequenceNumber = sequenceNumber+2;
													m.addObject(sequenceNumber);
													response.addObject(m);
													response.addObject(getMessageHMAC(m.getObjContents()));
												}
											}
										}
									}
								}
							}
						
						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);

					} 
					else if (message.getMessage().equals("DUSER")){
						response = new Envelope("Fail to delete user.");
						Envelope m = new Envelope("message");
						// If giving enough 2 information (1.username 2.token)
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
									
							if (msg.getObjContents().get(0) != null) {
								if (msg.getObjContents().get(1) != null) {
									if (msg.getObjContents().get(2) != null) {
									
										String username = (String) msg.getObjContents().get(0); // Extract the username
										SignedObject signedToken = (SignedObject) msg.getObjContents().get(1); 
										int msg_sq = (int) msg.getObjContents().get(2);
												
										if(msg_sq > (sequenceNumber)) {
											if (verify(signedToken, GroupServerKeypair.getPublic())) {
												if(checkHMAC(client_msg_hash, msg.getObjContents())) {
													Token token = getUnsignedToken(signedToken); // token
													if (deleteUser(username, token)) {
														response = new Envelope("OK"); // Success
													}
												}
											}
											sequenceNumber = sequenceNumber+2;
											m.addObject(sequenceNumber);
											response.addObject(m);
											response.addObject(getMessageHMAC(m.getObjContents()));
											
										}
									}
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					} 
					else if (message.getMessage().equals("CGROUP")) // Client wants to create a group
					{
						response = new Envelope("Fail to create group.");
						Envelope m = new Envelope("message");
							if (message.getObjContents().get(0) != null) {
								if (message.getObjContents().get(1) != null) {
									Envelope msg = (Envelope) message.getObjContents().get(0);
									byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
									
									if (msg.getObjContents().get(0) != null) {
										if (msg.getObjContents().get(1) != null) {
											if (msg.getObjContents().get(2) != null) {
												String groupName = (String) msg.getObjContents().get(0);
												SignedObject signedToken = (SignedObject) msg.getObjContents().get(1);
												int msg_sq = (int) msg.getObjContents().get(2);
												
												if(msg_sq > (sequenceNumber)) {
													if(checkHMAC(client_msg_hash, msg.getObjContents())) {
														if (verify(signedToken, GroupServerKeypair.getPublic())) {
															Token token = getUnsignedToken(signedToken);
															if (createGroup(groupName, token)) {
																response = new Envelope("OK");
																
															}
														}
													}
													sequenceNumber = sequenceNumber+2;
													m.addObject(sequenceNumber);
													response.addObject(m);
													response.addObject(getMessageHMAC(m.getObjContents()));
												}
												
											}
										}
									}
								}
							}
						

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					} 
					else if (message.getMessage().equals("DGROUP")) // Client wants to delete a group
					{
						response = new Envelope("Fail to delete group.");
						Envelope m = new Envelope("message");
						// Check parameter status
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
							
							if (msg.getObjContents().get(0) != null) {
								if (msg.getObjContents().get(1) != null) {
									if (msg.getObjContents().get(2) != null) {
										
										String groupname = (String) msg.getObjContents().get(0);
										SignedObject signedToken = (SignedObject) msg.getObjContents().get(1);
										int msg_sq = (int) msg.getObjContents().get(2);
											
										if(msg_sq > (sequenceNumber)) {
											if(checkHMAC(client_msg_hash, msg.getObjContents())) {
												if (verify(signedToken, GroupServerKeypair.getPublic())) {
													Token token = getUnsignedToken(signedToken);
													String username = token.getSubject();
													if (deleteGroup(groupname, username)) {
														response = new Envelope("OK");
													}
												}
											}
											sequenceNumber = sequenceNumber+2;
											m.addObject(sequenceNumber);
											response.addObject(m);
											response.addObject(getMessageHMAC(m.getObjContents()));
										}
									}
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);

					} 
					else if (message.getMessage().equals("LMEMBERS")) // Client wants a list of members in a group
					{
						response = new Envelope("Fail to list group member.");
						Envelope m = new Envelope("message");
						// Check parameter status
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
							
							if (checkEnvelopePara(3, msg)) {
								String groupname = (String) msg.getObjContents().get(0);
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(1);
								int msg_sq = (int) msg.getObjContents().get(2);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											ArrayList<String> memberlist = listMember(groupname, token);
											if (memberlist != null) {
												System.out.println(memberlist);
												response = new Envelope("OK");
												m.addObject(memberlist);
											}
										}
									}
									sequenceNumber = sequenceNumber+2;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
								
								
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);

					} 
					else if (message.getMessage().equals("AUSERTOGROUP")) // Client wants to add user to a group
					{
						response = new Envelope("Fail to add user to group.");
						Envelope m = new Envelope("message");
						
						// Check parameter status
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
							
							if (checkEnvelopePara(4, msg)) {
								String username = (String) msg.getObjContents().get(0);
								String groupname = (String) msg.getObjContents().get(1);
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(2);
								int msg_sq = (int) msg.getObjContents().get(3);
	
								if(msg_sq > sequenceNumber) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											if (addUserToGroup(username, groupname, token)) {
												response = new Envelope("OK");
											}
										}
									}
									sequenceNumber = sequenceNumber+2;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);

					} 
					else if (message.getMessage().equals("RUSERFROMGROUP")) // Client wants to remove user from a
					{
						response = new Envelope("Fail to remove user from group.");
						Envelope m = new Envelope("message");
						// Check parameter status
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
							
							if (msg.getObjContents().get(0) != null) {
								if (msg.getObjContents().get(1) != null) {
									if (msg.getObjContents().get(2) != null) {
										if (msg.getObjContents().get(3) != null) {
											String username = (String) msg.getObjContents().get(0);
											String groupname = (String) msg.getObjContents().get(1);
											SignedObject signedToken = (SignedObject) msg.getObjContents().get(2);
											int msg_sq = (int) msg.getObjContents().get(3);
				
											if(msg_sq > (sequenceNumber)) {
												if(checkHMAC(client_msg_hash, msg.getObjContents())) {
													if (verify(signedToken, GroupServerKeypair.getPublic())) {
														Token token = getUnsignedToken(signedToken);
														if (removeUserFromGroup(username, groupname, token)) {
															if(reduceGroupN(groupname, token)) {
																response = new Envelope("OK");
																
															}
														}
													}
												}
												sequenceNumber = sequenceNumber+2;
												m.addObject(sequenceNumber);
												response.addObject(m);
												response.addObject(getMessageHMAC(m.getObjContents()));
											}
										}
									}
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);

					}
					else if (message.getMessage().equals("LGROUP")) {
						response = new Envelope("Fail to list group");
						Envelope m = new Envelope("message");
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
								
							if (checkEnvelopePara(3, msg)) {
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(0);
								String username = (String) msg.getObjContents().get(1);
								int msg_sq = (int) msg.getObjContents().get(2);
	
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										sequenceNumber = sequenceNumber+1;
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											response = new Envelope("OK");
											m.addObject(listGroups(token, username));
										}
									}
									sequenceNumber = sequenceNumber+1;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}

					else if (message.getMessage().equals("CHECKPROFILE")) {
						response = new Envelope("Fail to check profile");
						Envelope m = new Envelope("message");
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
								
							if (checkEnvelopePara(3, msg)) {
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(0);
								String username = (String) msg.getObjContents().get(1);
								int msg_sq = (int) msg.getObjContents().get(2);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											response = new Envelope("OK");
											m.addObject(checkProfile(token, username));
										}
										sequenceNumber = sequenceNumber+2;
										m.addObject(sequenceNumber);
										response.addObject(m);
										response.addObject(getMessageHMAC(m.getObjContents()));
									}
								}
							}
						}
						
						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}

					else if (message.getMessage().equals("SETPRIVACY")) {
						response = new Envelope("Fail to set privacy");
						Envelope m = new Envelope("message");
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
								
							if (checkEnvelopePara(3, msg)) {
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(0);
								int level = (int) msg.getObjContents().get(1);
								int msg_sq = (int) msg.getObjContents().get(2);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											if (setPrivacy(token, level)) {
												response = new Envelope("OK");
											}
										}
									}
									sequenceNumber = sequenceNumber+2;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}
					
					else if (message.getMessage().equals("SETPROFILE")) {
						response = new Envelope("Fail to set profile");
						Envelope m = new Envelope("message");
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
								
							if (checkEnvelopePara(6, msg)) {
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(0);
								String firstname = (String) msg.getObjContents().get(1);
								String lastname = (String) msg.getObjContents().get(2);
								int age = (int) msg.getObjContents().get(3);
								String content = (String) msg.getObjContents().get(4);
								int msg_sq = (int) msg.getObjContents().get(5);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											if (setProfile(token, firstname, lastname, age, content)) {
												response = new Envelope("OK");
											}
										}
									}
									sequenceNumber = sequenceNumber+2;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}

					else if (message.getMessage().equals("GETGROUPKEY")) {
						response = new Envelope("Fail to get group key");
						Envelope m = new Envelope("message");
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
								
							if (checkEnvelopePara(3, msg)) {
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(0);
								String group = (String) msg.getObjContents().get(1);
								int msg_sq = (int) msg.getObjContents().get(2);
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											SecretKey hashedKey = getHashedGroupKey(token, group);
											response = new Envelope("OK");
											m.addObject(hashedKey);
										}
									}
									sequenceNumber = sequenceNumber+2;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
							}	
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}

					else if (message.getMessage().equals("GETGROUPN")) {
						response = new Envelope("Fail to get group N");
						Envelope m = new Envelope("message");
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
								
							if (checkEnvelopePara(3, msg)) {
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(0);
								String group = (String) msg.getObjContents().get(1);
								int msg_sq = (int) msg.getObjContents().get(2);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											int group_n = getGroupN(token, group);
											response = new Envelope("OK");
											m.addObject(group_n);
											
										}
									}
									sequenceNumber = sequenceNumber+2;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}

					else if (message.getMessage().equals("REDUCEGROUPN")) {
						response = new Envelope("Fail to reduce group N");
						Envelope m = new Envelope("message");
						
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
								
							if (checkEnvelopePara(3, msg)) {
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(0);
								String group = (String) msg.getObjContents().get(1);
								int msg_sq = (int) msg.getObjContents().get(2);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerKeypair.getPublic())) {
											Token token = getUnsignedToken(signedToken);
											reduceGroupN(group, token);
											response = new Envelope("OK");
										}
									}
									sequenceNumber = sequenceNumber+2;
									m.addObject(sequenceNumber);
									response.addObject(m);
									response.addObject(getMessageHMAC(m.getObjContents()));
								}
							}
						}

						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}

					else if (message.getMessage().equals("DISCONNECT")) // Client wants to disconnect
					{
						if (checkEnvelopePara(2, message)) {
							Envelope msg = (Envelope) message.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])message.getObjContents().get(1);
							
							if (checkEnvelopePara(1, msg)) {
								int msg_sq = (int) msg.getObjContents().get(0);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										sequenceNumber = sequenceNumber+1;
										socket.close(); // Close the socket
										proceed = false; // End this communication loop
										no_more_raw_msg = false;
									}
								}
							}	
						}
						
					} else {
						response = new Envelope("FAIL"); // Server does not understand client request
						SealedObject sealed_msg = new SealedObject(response, gs_cipher_encrypt);
						output.writeObject(sealed_msg);
					}
				}
				// Save latest data
				my_gs.SaveFile();
			} while (proceed);
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}
	}

	// Method to create tokens
	private Token createToken(String username, PublicKey fs_public) {
		System.out.println(my_gs.userList);
		// Check that user exists
		if (my_gs.userList.checkUser(username)) {
			// Issue a new token with server's name, user's name, and user's groups
			
			Token yourToken = new Token(my_gs.name, username, my_gs.userList.getUserGroups(username), fs_public);
			return yourToken;
		} else {
			return null;
		}
	}

	// Method to create a user
	private boolean createUser(String username, Token yourToken) {
		String requester = yourToken.getSubject();

		// Check if requester exists
		if (my_gs.userList.checkUser(requester)) {
			// Get the user's groups
			ArrayList<String> temp = my_gs.userList.getUserGroups(requester);
			// requester needs to be an administrator
			if (temp.contains("ADMIN")) {
				// Does user already exist?
				if (my_gs.userList.checkUser(username)) {
					return false; // User already exists
				} else {
					my_gs.userList.addUser(username);
					return true;
				}
			} else {
				return false; // requester not an administrator
			}
		} else {
			return false; // requester does not exist
		}
	}

	// Method to delete a user
	private boolean deleteUser(String username, Token yourToken) {
		String requester = yourToken.getSubject();

		// Does requester exist?
		if (my_gs.userList.checkUser(requester)) {
			// Admin should not be deleted
			if (!username.equals(requester)) {
				// user should be in grouplist
				if (my_gs.userList.checkUser(username)) {
					ArrayList<String> temp = my_gs.userList.getUserGroups(requester);
					// requester needs to be an administer
					if (temp.contains("ADMIN")) {
						// Does user exist?
						if (my_gs.userList.checkUser(username)) {

							// User needs deleted from the groups they belong
							ArrayList<String> deleteFromGroups = new ArrayList<String>();

							// This will produce a hard copy of the list of groups this user belongs
							for (int index = 0; index < my_gs.userList.getUserGroups(username).size(); index++) {
								deleteFromGroups.add(my_gs.userList.getUserGroups(username).get(index));
							}

							// Delete the user from the groups
							// If user is the owner, removeMember will automatically delete group!
							for (int index = 0; index < deleteFromGroups.size(); index++) {
								my_gs.groupList.removeMember(username, deleteFromGroups.get(index));
							}

							// If groups are owned, they must be deleted
							ArrayList<String> deleteOwnedGroup = new ArrayList<String>();

							// Make a hard copy of the user's ownership list
							for (int index = 0; index < my_gs.userList.getUserOwnership(username).size(); index++) {
								deleteOwnedGroup.add(my_gs.userList.getUserOwnership(username).get(index));
							}

							// Delete owned groups
							for (int index = 0; index < deleteOwnedGroup.size(); index++) {
								// Use the delete group method. Token must be created for this action
								deleteGroup(deleteOwnedGroup.get(index), username);
							}

							// Delete the user from the user list
							my_gs.userList.deleteUser(username);

							return true;
						}
					}
				}
			}
		}

		return false;

	}

	// Method to create a group
	private boolean createGroup(String groupName, Token token) {

		String creator = token.getSubject();
		// Does creator exist?
		if (my_gs.userList.checkUser(creator)) {
			// Does group name not yet be using?
			if (!my_gs.groupList.checkGroup(groupName)) {
				// add the ownership of this group to creator
				my_gs.userList.addOwnership(creator, groupName);
				// add this new group to creator's group list
				my_gs.userList.addGroup(creator, groupName);
				// add this new group to group list
				my_gs.groupList.addGroup(groupName);
				// add creator to group's member list
				my_gs.groupList.addMember(creator, groupName);

				return true;
			}
		}

		return false;
	}

	// Method to delete a group
	private boolean deleteGroup(String groupname, String deleter) {

		
		// Does user exist?
		if (my_gs.userList.checkUser(deleter)) {
			// Does deleter have the group ownership?
			ArrayList<String> ownership = my_gs.userList.getUserGroups(deleter);
			if (ownership.contains(groupname)) {
				ArrayList<String> memberlist = my_gs.groupList.getMemberList(groupname);

				for (String eachmember : memberlist) {
					// remover group from each group member
					my_gs.userList.removeGroup(eachmember, groupname);
				}
				// remove group from group list
				my_gs.groupList.deleteGroup(groupname);

				return true;
			}

		}

		return false;
	}

	private boolean addUserToGroup(String username, String groupname, Token token) {

		String adder = token.getSubject();

		// Does adder and user exist?
		if (my_gs.userList.checkUser(adder) && my_gs.userList.checkUser(username)) {
			// Does group exist?
			if (my_gs.groupList.checkGroup(groupname)) {
				// Does adder is a member of this group?
				if (my_gs.userList.getUserGroups(adder).contains(groupname)) {
					// Is user already in the group?
					ArrayList<String> group = my_gs.userList.getUserGroups(username);
					if (!group.contains(groupname)) {
						// add a new group to user's user list
						my_gs.userList.addGroup(username, groupname);
						// update group list with one more member
						my_gs.groupList.addMember(username, groupname);

						return true;
					}
				}
			}
		}

		return false;
	}

	private boolean removeUserFromGroup(String username, String groupname, Token token) {

		String remover = token.getSubject();

		// Does remover and user exist?
		if (my_gs.userList.checkUser(username) && my_gs.userList.checkUser(remover)) {
			// Does group exist?
			if (my_gs.groupList.checkGroup(groupname)) {
				// Does remover have the ownership of this group?
				ArrayList<String> ownership = my_gs.userList.getUserOwnership(remover);
				if (ownership.contains(groupname)) {
					// Delete group from user's user list
					my_gs.userList.removeGroup(username, groupname);
					// Delete user from group member list
					my_gs.groupList.removeMember(username, groupname);

					return true;
				}
			}
		}

		return false;
	}

	private boolean reduceGroupN(String groupname, Token token) {

		String remover = token.getSubject();

		// Does remover exist?
		if (my_gs.userList.checkUser(remover)) {
			// Does group exist?
			if (my_gs.groupList.checkGroup(groupname)) {
				// Does remover have the ownership of this group?
				ArrayList<String> ownership = my_gs.userList.getUserOwnership(remover);
				if (ownership.contains(groupname)) {
					// reduce N
					my_gs.groupList.reduceN(groupname);
					System.out.println(my_gs.groupList.getN(groupname));

					return true;
				}
			}
		}

		return false;
	}

	private List<String> listGroups(Token token, String username) {

		String requester = token.getSubject();

		// Does requester exist?
		if (my_gs.userList.checkUser(requester)) {
			// Does username exist?
			if (my_gs.userList.checkUser(username)) {
				// You want to check your own group list?
				// Or you are admin, you can check everyone's group list
				if (requester.equals(username) || token.getGroups().contains("ADMIN")) {
					System.out.printf("Successfully get %s's group list \n", username);
					return my_gs.userList.getUserGroups(username);
				}
				System.out.println("Not ADMIN, or have no right to check that user's group list");
			}
			System.out.println(username + " doesn't exist");
		}

		return null;

	}

	private ArrayList<String> checkProfile(Token token, String username) {

		String requester = token.getSubject();

		// Does requester exist?
		if (my_gs.userList.checkUser(requester)) {
			// Does username exist?
			if (my_gs.userList.checkUser(username)) {
				System.out.printf("Successfully get %s's profile \n", username);
				return my_gs.userList.getProfile(requester, username);
			}
			System.out.println(username + " doesn't exist");
		}

		return null;
	}

	private ArrayList<String> listMember(String groupname, Token token) {

		String requester = token.getSubject();

		// Does requester exist?
		if (my_gs.userList.checkUser(requester)) {
			// Does group exist?
			if (my_gs.groupList.checkGroup(groupname)) {
				// Is requester a member of this group?
				ArrayList<String> grouplist = my_gs.userList.getUserGroups(requester);
				if (grouplist.contains(groupname)) {
					return my_gs.groupList.getMemberList(groupname);
				}
			}
		}

		return null;
	}

	private boolean setPrivacy(Token token, int level) {
		String requestor = token.getSubject();

		// Does user exist?
		if (my_gs.userList.checkUser(requestor)) {
			my_gs.userList.setPrivacy(requestor, level);
			System.out.printf("%s's profile has set to privacy level %d \n", requestor, level);
			return true;
		}
		return false;
	}
	
	private boolean setProfile(Token token, String firstname, String lastname, int age, String content) {
		String requestor = token.getSubject();

		// Does user exist?
		if (my_gs.userList.checkUser(requestor)) {
			my_gs.userList.setProfile(requestor, firstname, lastname, age, content);
			System.out.printf("%s's profile is set \n", requestor);
			return true;
		}
		return false;
	}

	private SecretKey getHashedGroupKey(Token token, String group) throws NoSuchAlgorithmException {
		SecretKey key = null;
		String requestor = token.getSubject();

		// Does group exist?
		if (my_gs.groupList.checkGroup(group)) {
			// Is user a group member
			if (my_gs.groupList.getMemberList(group).contains(requestor)) {
				key = my_gs.groupList.getGroupKey(group);
				System.out.println("get key from server " + key);
				int n = my_gs.groupList.getN(group);
				return SHA2(key, n);
			}
			System.err.println("Not a group member");
		}
		System.err.println("Group doesn't exist");

		return key;
	}

	private SecretKey SHA2(SecretKey key, int n) throws NoSuchAlgorithmException {

		MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
		byte[] keyBytes = key.getEncoded();

		// apply SHA2 to key n times
		for (int i = 0; i < n; i++)
			keyBytes = sha256.digest(keyBytes);

		// turn it back to SecretKey
		SecretKey hasedKey = new SecretKeySpec(keyBytes, 0, keyBytes.length, "AES");

		return hasedKey;
	}

	private int getGroupN(Token token, String group) {
		String requestor = token.getSubject();
		int n = -1;

		// Does group exist?
		if (my_gs.groupList.checkGroup(group)) {
			// Is user a group member
			ArrayList<String> grouplist = my_gs.userList.getUserGroups(requestor);
			if (grouplist.contains(group)) {
				n = my_gs.groupList.getN(group);
				System.out.println("Get group n: " + n);
			} else {
				System.err.println("Not a group member of " + group);
			}
		} else {
			System.err.println("Group doesn't exist");
		}

		return n;
	}

	/*
	private ChatRoom createChatRoom(String group, Token token) {

		String requester = token.getSubject();
		System.out.println("$$$$$$" + group);

		// Does group exist?
		if (my_gs.groupList.checkGroup(group)) {
			System.out.println("group exist");
			// Are you in that group
			if (token.getGroups().contains(group)) {
				System.out.println("in group");
				ChatRoom chatRoom = new ChatRoom(group, 3, requester);
				return chatRoom;
			}
		}

		System.err.println("Cannot create chatroom");
		return null;
	}
	*/

	private boolean checkEnvelopePara(int para_num, Envelope e) {

		// Does envelope provide enough parameters?
		if (e.getObjContents().size() == para_num) {
			for (Object obj : e.getObjContents()) {
				if (obj == null) {
					System.err.println("Some of the parameters are null.");
					return false;
				}
			}

			return true;
		}
		System.err.println("Incorrect number of parameters are provided.");
		return false;
	}

	public static SignedObject sign(Token token, PrivateKey privateKey) throws Exception {
		Signature signature = Signature.getInstance("SHA1withRSA");
		SignedObject signedObject = new SignedObject(token, privateKey, signature);
		return signedObject;
	}

	public static boolean verify(SignedObject signedToken, PublicKey publicKey) throws Exception {
		Signature sig = Signature.getInstance("SHA1withRSA");
		boolean verified = signedToken.verify(publicKey, sig);
		System.out.println("Is signed Object verified ? " + verified);

		return verified;
	}
	
	public boolean checkHMAC(byte[] client_msg_hash, ArrayList<Object> message) throws Exception {
		
			byte[] group_msg_hash = getMessageHMAC(message);
			
			if(MessageDigest.isEqual(group_msg_hash, client_msg_hash)) {
				return true;
			}else {
				return false;
			}
			
	}
	
	public static byte[] concatenateArrays(byte[] arr1, byte[] arr2) {
		byte[] arr3 = new byte[arr1.length + arr2.length];
		for (int i = 0; i < arr1.length; i++) {
			arr3[i] = arr1[i];
		}
		for (int i = 0; i < arr2.length; i++) {
			arr3[i + arr1.length] = arr2[i];
		}
		return arr3;
	}
	
	

	public byte[] getMessageHMAC(ArrayList<Object> message) throws Exception {
		byte[] hmac = null;
		//byte[] content = concatenateArrays(message.toString().getBytes(), iv);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(message);
		oos.flush();
		byte[] content = bos.toByteArray();
		
		try {		
			Mac mac = Mac.getInstance("HmacSHA256");
			mac.init(integrity_key);
			hmac = mac.doFinal(content);
			//System.out.println("content is " +Arrays.toString(content));
			//System.out.println("hmac(m) is " +Arrays.toString(hmac));
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return hmac;
	}

	public static Token getUnsignedToken(SignedObject signedToken) throws ClassNotFoundException, IOException {
		return (Token) signedToken.getObject();
	}
}
