import java.io.IOException;
import java.security.Key;
import java.security.PublicKey;
import java.security.SecureRandom;

import javax.crypto.spec.IvParameterSpec;

public class CAclient extends Client {
	
	private final byte[] iv = generateIv();

	/*
	public boolean connect(final String server, final int port) {
		return true;
	}
	*/
	public byte[] generateIv() {
		SecureRandom rnd = new SecureRandom();
		byte var[] = new byte[16];
		rnd.nextBytes(var);
		IvParameterSpec ivSpec = new IvParameterSpec(var);
		var = ivSpec.getIV();
		return var;
	}

	public void disconnect() {
		if (isConnected()) {
			try {
				Envelope message = new Envelope("DISCONNECT");
				output.writeObject(message);

			} catch (Exception e) {
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
			}
		}
	}
	
	public byte[] getIv() {
		if(iv == null) {
			System.out.println("null iv");
			/*try {
				Envelope message = new Envelope("setIv");
				message.addObject(iv);
				output.writeObject(message);
				
				Envelope res = (Envelope) input.readObject();
				
				if (res.getMessage().equals("OK")) {
					return iv;
				}
				
			}catch (Exception e) {
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
			}*/
		}
		
		return iv;
	}

	public PublicKey getPublicKeyFromCA(String fileServerName) throws ClassNotFoundException, IOException {
		PublicKey key = null;

		// Send request to CA
		Envelope req = new Envelope("Get Public Key");
		req.addObject(fileServerName);
		output.writeObject(req);
		System.out.printf("Waiting for %s's public key from CA \n", fileServerName);

		// Get key from CA
		Envelope res = (Envelope) input.readObject();
		if (res.getMessage().equals("OK")) {
			if (res.getObjContents().get(0) != null) {
				key = (PublicKey) res.getObjContents().get(0);
				System.out.println("Successfully get public key from CA");
				return key;
			}
		}

		System.out.println("Didn't get key from CA");
		return key;
	}
	
	public PublicKey getGroupServerPublicKeyFromCA() throws ClassNotFoundException, IOException {
		PublicKey key = null;

		// Send request to CA
		Envelope req = new Envelope("Group Server Public Key");
		output.writeObject(req);
		System.out.printf("Waiting for group server's public key from CA \n");

		// Get key from CA
		Envelope res = (Envelope) input.readObject();
		if (res.getMessage().equals("OK")) {
			if (res.getObjContents().get(0) != null) {
				key = (PublicKey) res.getObjContents().get(0);
				System.out.println("Successfully get public key from CA");
				return key;
			}
		}

		System.out.println("Didn't get key from CA");
		return key;
	}
}
