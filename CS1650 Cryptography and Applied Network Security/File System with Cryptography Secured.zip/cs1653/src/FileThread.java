/* File worker thread handles the business of uploading, downloading, and removing files for clients with valid tokens */

import java.lang.Thread;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignedObject;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileThread extends Thread
{
	private final Socket socket;
	private final FileServer my_fs;
	
	private SecretKey symmetricKey;
	private String file_server_challenge;
	private Cipher fs_cipher_decrypt;
	private Cipher fs_cipher_encrypt;
	private boolean no_more_raw_msg = false;
	private KeyPair FileServerKeypair = null;
	private String fsName;
	private SecretKey integrity_key;
	private PublicKey GroupServerPublicKey;
	private int sequenceNumber;
	


	public FileThread(Socket _socket, FileServer _fs, KeyPair FileServerKeypair) throws NoSuchAlgorithmException, IOException, InvalidKeySpecException {
		socket = _socket;
		my_fs = _fs;
		fsName = my_fs.FILE_SERVER_NAME;// get fileServerName
		//addPublicKeyToCA(FileServerKeypair.getPublic(), fsName);// pass in fileServer pubKey and name
		GroupServerPublicKey = getPublicKeyFromCA();
		this.FileServerKeypair = FileServerKeypair;
	}

	
	public void run()
	{
		boolean proceed = true;
		try
		{
			System.out.println("*** New connection from " + socket.getInetAddress() + ":" + socket.getPort() + "***");
			final ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
			final ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
			Envelope response;

			do
			{

				my_fs.loadFile();
				
				if(!no_more_raw_msg) {
					
					Envelope e = (Envelope)input.readObject();
					System.out.println("Request received: " + e.getMessage());
					
					if(e.getMessage().equals("Generate_Shared_Key")) {
						
						
						if(e.getObjContents().size() < 2)
						{
							response = new Envelope("FAIL");
						}
						else
						{
							response = new Envelope("FAIL");
							
							if(e.getObjContents().get(0) != null)
							{
								if(e.getObjContents().get(1) != null)
								{
									String username = (String)e.getObjContents().get(0); //Extract the username
									PublicKey clientPublicKey = (PublicKey)e.getObjContents().get(1); //Extract client's key
									
									KeyPair sym_KeyPair = DiffieHellman.genKeyPair();
							      	KeyAgreement keyAgreement = DiffieHellman.genKeyAgreement(sym_KeyPair);
							      	symmetricKey = DiffieHellman.generateSecretKey(clientPublicKey, keyAgreement);
							      	
							      	fs_cipher_encrypt = Cipher.getInstance("AES"); 
						            fs_cipher_encrypt.init(Cipher.ENCRYPT_MODE, symmetricKey);
						            
						            fs_cipher_decrypt = Cipher.getInstance("AES"); 
						            fs_cipher_decrypt.init(Cipher.DECRYPT_MODE, symmetricKey);
						            
									
									System.out.println("file symmetric key is " + Base64.getEncoder().encodeToString(symmetricKey.getEncoded()));
									response = new Envelope("OK"); //Success
									Signature signature = Signature.getInstance("SHA1withRSA");
									SignedObject signedSymmetricPublic = new SignedObject(sym_KeyPair.getPublic(), FileServerKeypair.getPrivate(), signature);
							 		response.addObject(signedSymmetricPublic);//g^f mod q
							 		response.addObject(fsName);
			
							 		no_more_raw_msg = true;
							 		
								}
							}
						}
						
						output.writeObject(response);
					}


				}else {
					SealedObject encrypt_msg = (SealedObject)input.readObject();
					Envelope e = (Envelope)encrypt_msg.getObject(fs_cipher_decrypt);
					
					if(e.getMessage().equals("authenticate file server")) {
						
						if(e.getObjContents().size() < 3)
						{
							response = new Envelope("FAIL");
						}
						else
						{
							response = new Envelope("FAIL");
							
							if(e.getObjContents().get(0) != null)
							{
								if(e.getObjContents().get(1) != null)
								{
									if(e.getObjContents().get(2) != null)
									{
										sequenceNumber = (int)e.getObjContents().get(0); // set up sequence number in file server
										
										SignedObject signedToken = (SignedObject)e.getObjContents().get(1);
										SealedObject cipherText_RSA = (SealedObject)e.getObjContents().get(2); 
										
										String client_c = (String)cipherText_RSA.getObject(FileServerKeypair.getPrivate()); //get client challenge
			
										if (verify(signedToken, GroupServerPublicKey)) {
											
											String temp = symmetricKey.toString() + "Integrity";
											try {
												MessageDigest md = MessageDigest.getInstance("SHA-256");
												md.update(temp.getBytes("UTF-8"));
												byte[] integrate_hash = md.digest();
												integrity_key = new SecretKeySpec(integrate_hash, 0, integrate_hash.length, "AES");
												System.out.println("file server's integrate key is " 
														+ Base64.getEncoder().encodeToString(integrity_key.getEncoded()));
												
												response = new Envelope("OK"); //Success
										        response.addObject(client_c);
										        sequenceNumber = sequenceNumber+1;
										        response.addObject(sequenceNumber);
											 	no_more_raw_msg = true;
											 	System.out.println("file server gets token and generate integrity key");
												
											} catch (Exception ex) {
												ex.printStackTrace();
												System.out.println("file server generate integrity key fail");
											}
								
									        
										}
									}
									 
								}
							}
						    else {
						         System.out.println("null message send to file server");
						         response = new Envelope("FAIL"); //Success
						    }
						}
						SealedObject sealed_msg = new SealedObject(response, fs_cipher_encrypt);
						output.writeObject(sealed_msg);
						
					}
					//----------------------File server functionality---------------------------------

					// Handler to list files that this user is allowed to see
					else if(e.getMessage().equals("LFILES"))
					{
							response = new Envelope("Fail to list files.");
							Envelope m = new Envelope("message");
							
							//Check envelope parameters
							//group name, token
						    if(checkEnvelopePara(2, e)) 
						    {
						    	Envelope msg = (Envelope) e.getObjContents().get(0);
								byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
								if(checkEnvelopePara(2, msg)) {
									SignedObject signedToken = (SignedObject) msg.getObjContents().get(0); // Extract token
									int sq = (int)msg.getObjContents().get(1);
									
									System.out.printf("msg sq number %s\n",sq);
									System.out.printf("file server sq number %s\n",sequenceNumber);
									if(sq >= (sequenceNumber)) {
										if(checkHMAC(client_msg_hash, msg.getObjContents())) {
											if (verify(signedToken, GroupServerPublicKey)) {
												Token token = getUnsignToken(signedToken);
									 									
										    	List<ShareFile> list = listFiles(token);
										    	if(list != null)
										    	{
										    		response = new Envelope("OK");
										    		m.addObject(list);
										    	}
											}
										}
										sequenceNumber = sq+1;
										m.addObject(sequenceNumber);
										response.addObject(m);
										response.addObject(getMessageHMAC(m.getObjContents()));
									}
								}
						    }
						    
						 SealedObject sealed_msg = new SealedObject(response, fs_cipher_encrypt);
						 output.writeObject(sealed_msg);
					}
					else if(e.getMessage().equals("UPLOADF"))
					{
							response = new Envelope("Fail to upload");
							
							System.out.println("THread get message");
							if(checkEnvelopePara(2, e)) 
						    {
								Envelope msg = (Envelope) e.getObjContents().get(0);
								byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
							
								if(msg.getObjContents().size() > 3) 
								{	
									System.out.println("1");
									String remotePath = (String)msg.getObjContents().get(0);
									String groupname = (String)msg.getObjContents().get(1);
									SignedObject signedToken = (SignedObject) msg.getObjContents().get(2); // Extract token
									int n = (int) msg.getObjContents().get(3);
									byte[] randIV = (byte[]) msg.getObjContents().get(4);
									int sq = (int)msg.getObjContents().get(5);
									
									if(sq >= (sequenceNumber)) {
										
										if(checkHMAC(client_msg_hash, msg.getObjContents())) {
											
											if (verify(signedToken, GroupServerPublicKey)) {
												
												Token token = getUnsignToken(signedToken);
												System.out.println("HO");
												if (uploadFilesConfirmation(groupname, remotePath, token))
												{
													System.out.println("THread confirm");
													
													File file = new File("shared_files/"+remotePath.replace('/', '_'));
													file.createNewFile();
													FileOutputStream fos = new FileOutputStream(file);
													System.out.printf("Successfully created file %s\n", remotePath.replace('/', '_'));
					
													response = new Envelope("READY"); //Success
													Envelope m1 = new Envelope("message");
													sequenceNumber = sq+1;
													m1.addObject(sequenceNumber);
													response.addObject(m1);
													response.addObject(getMessageHMAC(m1.getObjContents()));
													SealedObject sealed_msg = new SealedObject(response, fs_cipher_encrypt);
													output.writeObject(sealed_msg);
													
													SealedObject encrypt_msg_1 = (SealedObject)input.readObject();
													e = (Envelope)encrypt_msg_1.getObject(fs_cipher_decrypt);
													
													while (e.getMessage().equals("CHUNK")) 
													{
														fos.write((byte[])e.getObjContents().get(0), 0, (Integer)e.getObjContents().get(1));
														response = new Envelope("READY"); //Success
														Envelope m2 = new Envelope("message");
														//sequenceNumber = sq+1;
														m2.addObject(sequenceNumber);
														response.addObject(m2);
														response.addObject(getMessageHMAC(m2.getObjContents()));
														SealedObject sealed_m = new SealedObject(response, fs_cipher_encrypt);
														output.writeObject(sealed_m);
														
														SealedObject encrypt_m = (SealedObject)input.readObject();
														e = (Envelope)encrypt_m.getObject(fs_cipher_decrypt);
														
													}
					
													if(e.getMessage().equals("EOF")) {
														System.out.printf("Transfer successful file %s\n", remotePath);
														FileServer.fileList.addFile(token.getSubject(), groupname, remotePath, n, randIV);
														response = new Envelope("OK"); //Success
													}
													else {
														System.out.printf("Error reading file %s from client\n", remotePath);
														response = new Envelope("ERROR-TRANSFER"); //Success
													}
													
													System.out.println("THread close");
													fos.close();
												}
											}
										}
										Envelope m3 = new Envelope("message");
										sequenceNumber = sq+1;
										m3.addObject(sequenceNumber);
										response.addObject(m3);
										response.addObject(getMessageHMAC(m3.getObjContents()));
									}
								}
							}
						
							System.out.printf("file server sq number %s\n",sequenceNumber);
							System.out.println("THread reply");
							SealedObject sealed_msg = new SealedObject(response, fs_cipher_encrypt);
							output.writeObject(sealed_msg);
					}
					else if (e.getMessage().equals("DOWNLOADF")) {
						
						if(checkEnvelopePara(2, e)) 
					    {
							Envelope msg = (Envelope) e.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
	
							String remotePath = (String)msg.getObjContents().get(0);
							ShareFile sf = FileServer.fileList.getFile("/"+remotePath);
							SignedObject signedToken = (SignedObject) msg.getObjContents().get(1); // Extract token
							int sq = (int)msg.getObjContents().get(2);
							
							if(sq >= (sequenceNumber)) {
								if(checkHMAC(client_msg_hash, msg.getObjContents())) {

									if (verify(signedToken, GroupServerPublicKey)) {
										Token token = getUnsignToken(signedToken);
									if (sf == null) {
										System.out.printf("Error: File %s doesn't exist\n", remotePath);
										e = new Envelope("ERROR_FILEMISSING");
										Envelope m2 = new Envelope("message");
										sequenceNumber = sq+1;
										m2.addObject(sequenceNumber);
										e.addObject(m2);
										e.addObject(getMessageHMAC(m2.getObjContents()));
										SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
										output.writeObject(sealed_msg);
									}
									else if (!token.getGroups().contains(sf.getGroup())){
										System.out.printf("Error user %s doesn't have permission\n", token.getSubject());
										e = new Envelope("ERROR_PERMISSION");
										Envelope m2 = new Envelope("message");
										sequenceNumber = sq+1;
										m2.addObject(sequenceNumber);
										e.addObject(m2);
										e.addObject(getMessageHMAC(m2.getObjContents()));
										SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
										output.writeObject(sealed_msg);
									}
									else {
			
										try
										{
											File f = new File("shared_files/_"+remotePath.replace('/', '_'));
										if (!f.exists()) {
											System.out.printf("Error file %s missing from disk\n", "_"+remotePath.replace('/', '_'));
											e = new Envelope("ERROR_NOTONDISK");
											Envelope m2 = new Envelope("message");
											sequenceNumber = sq+1;
											m2.addObject(sequenceNumber);
											e.addObject(m2);
											e.addObject(getMessageHMAC(m2.getObjContents()));
											SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
											output.writeObject(sealed_msg);
			
										}
										else {
											FileInputStream fis = new FileInputStream(f);
			
											do {
												byte[] buf = new byte[4096];
												if (e.getMessage().compareTo("DOWNLOADF")!=0) {
													System.out.printf("Server error: %s\n", e.getMessage());
													break;
												}
												e = new Envelope("CHUNK");
												int n = fis.read(buf); //can throw an IOException
												if (n > 0) {
													System.out.printf(".");
												} else if (n < 0) {
													System.out.println("Read error");
			
												}
			
												e.addObject(buf);
												e.addObject(new Integer(n));
												
												SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
												output.writeObject(sealed_msg);
												
												SealedObject encrypt = (SealedObject)input.readObject();
												e = (Envelope)encrypt.getObject(fs_cipher_decrypt);
												
												
											}while (fis.available()>0);
	
									//If server indicates success, return the member list
											if(e.getMessage().compareTo("DOWNLOADF")==0)
											{
			
												e = new Envelope("EOF");
												Envelope m2 = new Envelope("message");
												sequenceNumber = sq+1;
												m2.addObject(sequenceNumber);
												e.addObject(m2);
												e.addObject(getMessageHMAC(m2.getObjContents()));
												SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
												output.writeObject(sealed_msg);
												
												SealedObject encrypt = (SealedObject)input.readObject();
												e = (Envelope)encrypt.getObject(fs_cipher_decrypt);
												
												if(e.getMessage().compareTo("OK")==0) {
													//sequenceNumber = (int)msg1.getObjContents().get(0);
													System.out.printf("File data upload successful\n");
												}
												else {
													//sequenceNumber = (int)msg1.getObjContents().get(0);
													System.out.printf("Upload failed: %s\n", e.getMessage());
			
												}
											}
											else {
			
												System.out.printf("Upload failed: %s\n", e.getMessage());
			
											}
										}
									}
									catch(Exception e1)
									{
										System.err.println("Error: " + e.getMessage());
										e1.printStackTrace(System.err);
		
									}
								}
							}
						}
						}
						}
					}
					else if (e.getMessage().equals("DELETEF")) {
						

						if(checkEnvelopePara(2, e)) 
					    {
							Envelope msg = (Envelope) e.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
							Envelope m2 = new Envelope("message");
							
							if(checkEnvelopePara(3, msg)) 
						    {
								String remotePath = (String)msg.getObjContents().get(0);
								ShareFile sf = FileServer.fileList.getFile("/"+remotePath);
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(1); // Extract token
								int sq = (int)msg.getObjContents().get(2);
								
								if(sq >= (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										if (verify(signedToken, GroupServerPublicKey)) {
											Token token = getUnsignToken(signedToken);
											if (sf == null) {
												System.out.printf("Error: File %s doesn't exist\n", remotePath);
												e = new Envelope("ERROR_DOESNTEXIST");
											}
											else if (!token.getGroups().contains(sf.getGroup())){
												System.out.printf("Error user %s doesn't have permission\n", token.getSubject());
												e = new Envelope("ERROR_PERMISSION");
											}
											else {
					
												try
												{
													File f = new File("shared_files/"+"_"+remotePath.replace('/', '_'));
					
													if (!f.exists()) {
														System.out.printf("Error file %s missing from disk\n", "_"+remotePath.replace('/', '_'));
														e = new Envelope("ERROR_FILEMISSING");
													}
													else if (f.delete()) {
														System.out.printf("File %s deleted from disk\n", "_"+remotePath.replace('/', '_'));
														FileServer.fileList.removeFile("/"+remotePath);
														e = new Envelope("OK");
														// remove file from list
														my_fs.fileList.removeFile(remotePath);
													}
													else {
														System.out.printf("Error deleting file %s from disk\n", "_"+remotePath.replace('/', '_'));
														e = new Envelope("ERROR_DELETE");
													}	
					
												}
												catch(Exception e1)
												{
													System.err.println("Error: " + e1.getMessage());
													e1.printStackTrace(System.err);
													e = new Envelope(e1.getMessage());
												}
											}
										}
									}
									sequenceNumber = sq+1;
									m2.addObject(sequenceNumber);
									e.addObject(m2);
									e.addObject(getMessageHMAC(m2.getObjContents()));
								}	
						    }
							SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
							output.writeObject(sealed_msg);
	
						}
					
					}else if (e.getMessage().equals("GETFILEGROUP")) {
							

							if(checkEnvelopePara(2, e)) 
						    {
								Envelope msg = (Envelope) e.getObjContents().get(0);
								byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
								Envelope m2 = new Envelope("message");
							
								String file = (String) msg.getObjContents().get(0);
								SignedObject signedToken = (SignedObject) msg.getObjContents().get(1);
								int sq = (int)msg.getObjContents().get(2);
								System.out.println("sq is "+ sq +" and sequence Num in fs is "+ sequenceNumber);
								
								if(sq >= (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										
										System.out.println("Attempting to get file group");
										
										if (verify(signedToken, GroupServerPublicKey)) {
											Token token = getUnsignToken(signedToken);
											String group = getFileGroup(token, file);
											System.out.println("After get file group: " + group);
											e = new Envelope("OK");
											m2.addObject(group);
										}
									}
									sequenceNumber = sq+1;
									m2.addObject(sequenceNumber);
									e.addObject(m2);
									e.addObject(getMessageHMAC(m2.getObjContents()));
								}
						    }
							
							SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
							output.writeObject(sealed_msg);
					
					}else if (e.getMessage().equals("GETFILEN")) {
						
						if(checkEnvelopePara(2, e)) 
					    {
							Envelope msg = (Envelope) e.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
							Envelope m2 = new Envelope("message");
							
							String file = (String) msg.getObjContents().get(0);
							SignedObject signedToken = (SignedObject) msg.getObjContents().get(1);
							int sq = (int)msg.getObjContents().get(2);
							
							if(sq >= (sequenceNumber)) {
								if(checkHMAC(client_msg_hash, msg.getObjContents())) {
									if (verify(signedToken, GroupServerPublicKey)) {
										Token token = getUnsignToken(signedToken);
										int n = getFileN(token, file);
										e = new Envelope("OK");
										m2.addObject(n);
									}
								}
								sequenceNumber = sq+1;
								m2.addObject(sequenceNumber);
								e.addObject(m2);
								e.addObject(getMessageHMAC(m2.getObjContents()));
							}
					    }
							SealedObject sealed_msg = new SealedObject(e, fs_cipher_encrypt);
							output.writeObject(sealed_msg);
					}
					
					else if (e.getMessage().equals("GETFILEIV")) {

						if(e.getObjContents().size()<2){
							response = new Envelope("FAIL");
						} else {
							response = new Envelope("FAIL.");

							if (e.getObjContents().get(0) != null && e.getObjContents().get(1) != null) {
								Envelope msg = (Envelope) e.getObjContents().get(0);
								byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
								
								if(checkHMAC(client_msg_hash, msg.getObjContents())) {
									System.out.println("hash message match");
									
									if (msg.getObjContents().size()==3) {
										String file = (String) msg.getObjContents().get(0);
										SignedObject signedToken = (SignedObject) msg.getObjContents().get(1);
										int msg_sq = (int)msg.getObjContents().get(2);
											
											System.out.println("Attempting to get file group...");
											if(msg_sq>sequenceNumber) {
												sequenceNumber += 2;
												if (verify(signedToken, GroupServerPublicKey)) {
													
													Token token = getUnsignToken(signedToken);
													byte[] IV = getFileIV(token, file);
													
													response = new Envelope("OK");
													Envelope m = new Envelope("message");
													m.addObject(IV);
													m.addObject(sequenceNumber);
													response.addObject(m);
													response.addObject(getMessageHMAC(m.getObjContents()));
												}else {
													System.out.println("Cannot verify token.");
												}
											}else {
												System.out.println("sequenceNumber doesn't match.");
											}
											
									}else {
										System.out.println("msg size wrong.");
									}
								}else {
									System.out.println("HMAC doesn't match.");
								}
							}else {
								System.out.println("Null content.");
							}
						
						}
						
						SealedObject sealed_msg = new SealedObject(response, fs_cipher_encrypt);
						output.writeObject(sealed_msg);
						
					}
					
					else if(e.getMessage().equals("DISCONNECT"))
					{
						
						if (checkEnvelopePara(2, e)) {
							Envelope msg = (Envelope) e.getObjContents().get(0);
							byte[] client_msg_hash = (byte[])e.getObjContents().get(1);
							
							if (checkEnvelopePara(1, msg)) {
								int msg_sq = (int) msg.getObjContents().get(0);
								
								if(msg_sq > (sequenceNumber)) {
									if(checkHMAC(client_msg_hash, msg.getObjContents())) {
										sequenceNumber = sequenceNumber+1;
										socket.close(); // Close the socket
										proceed = false; // End this communication loop
										no_more_raw_msg = false;
									}
								}
							}	
						}
					}			
				}
				
				my_fs.saveFile();
			} while(proceed);
			
		}catch(Exception e){
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
		}
	}
	
	
			private List<ShareFile> listFiles(Token token) {
				
				String requester = token.getSubject();
				ArrayList<ShareFile> list = FileServer.fileList.getFiles();
				List<String> groups = token.getGroups();
				List<ShareFile> returnList = new ArrayList<ShareFile>();
	
				System.out.println("Files:");
				//Is requester in this group
				for(ShareFile file: list)
				{
					if(groups.contains(file.getGroup()))
					{
						System.out.println(file.getPath());
						returnList.add(file);
					}
				}
				
				System.out.println("Server is sending file list to client...");
				return returnList;
				
			}
			
			private boolean uploadFilesConfirmation(String groupname, String remotePath, Token token) {
				
				System.out.println("Upload confirm");
				//Does file already exist?
				if(!FileServer.fileList.checkFile(remotePath)) 
				{
					System.out.println("User belongs to group: " + groupname + " ?");
					for (Object group: token.getGroups().toArray())
					{
						System.out.println(group.toString());
					}
					
					//Is requester a member of this group?
					if(token.getGroups().contains(groupname))
					{
						return true;
					}
				} else {
					System.out.println("This file already exist.");
				}
				
				return false;
			}
	
			private boolean checkEnvelopePara(int para_num, Envelope e) {
				
				//Does envelope provide enough parameters?
				if(e.getObjContents().size() == para_num)
				{
					for(Object obj: e.getObjContents())
					{
						if(obj == null)
						{
							System.err.println("Some of the parameters are null.");
							return false;	
						}
					}
					
					return true;
				}
				System.err.println("Incorrect number of parameters are provided.");
				return false;
			}
			
			private static PublicKey getPublicKeyFromCA() {
				
				PublicKey key = null;
				
				CAclient cc = new CAclient();
				cc.connect("127.0.0.1", 9999);
				
				try {
					key = cc.getGroupServerPublicKeyFromCA();
					cc.disconnect();
					
				} catch (ClassNotFoundException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return key;
			}
			
			public boolean verify(SignedObject signedToken, PublicKey publicKey) throws Exception {

				Signature sig = Signature.getInstance("SHA1withRSA");
				boolean verified = signedToken.verify(publicKey, sig);
				System.out.println("Is signed Object signed by group server public key? " + verified);
				if(verified) {
					Token token = getUnsignToken(signedToken);
					PublicKey token_fs_key = token.getFileServerKey();
					if(token_fs_key.equals(FileServerKeypair.getPublic())) {
						System.out.println("file server's public key in the token is matched");
						return true;
					}else {
						return false;
					}
				}else {
					return false;
				}
			}

			public static Token getUnsignToken(SignedObject signedToken) throws ClassNotFoundException, IOException {
				return (Token) signedToken.getObject();
			}
			
			private static String getFileGroup(Token token, String file) {
				String group = null;
				file = "/" + file;
				
				// Does file exist?
				if(FileServer.fileList.checkFile(file)) {
					// Get file group
					group = FileServer.fileList.getFile(file).getGroup();
					System.out.printf("File: %s, is belongs to group:s \n", file, group);
				} else {
					System.out.println("File doesn't exist");
				}
				
				return group;
			}
			
			private static int getFileN(Token token, String file) {
				int n = -1;
				file = "/" + file;
				
				// Does file exist?
				if(FileServer.fileList.checkFile(file)) {
					// Get file group
					n = FileServer.fileList.getFile(file).getN();
					System.out.println("Found property n of this file: " + String.valueOf(n));
				} else {
					System.out.println("File doesn't exist");
				}
				
				return n;
			}
			
			private static byte[] getFileIV(Token token, String file) {
				byte[] IV = null;
				file = "/" + file;
				
				// Does file exist?
				if(FileServer.fileList.checkFile(file)) {
					// Get file group
					IV = FileServer.fileList.getFile(file).getIV();
					System.out.println("Found IV n of this file");
				} else {
					System.out.println("File doesn't exist");
				}
				
				return IV;
			}
			
			
			public boolean checkHMAC(byte[] client_msg_hash, ArrayList<Object> message) throws Exception {
				
				byte[] group_msg_hash = getMessageHMAC(message);
				
				if(MessageDigest.isEqual(group_msg_hash, client_msg_hash)) {
					return true;
				}else {
					return false;
				}
				
			}
			
			public static byte[] concatenateArrays(byte[] arr1, byte[] arr2) {
				byte[] arr3 = new byte[arr1.length + arr2.length];
				for (int i = 0; i < arr1.length; i++) {
					arr3[i] = arr1[i];
				}
				for (int i = 0; i < arr2.length; i++) {
					arr3[i + arr1.length] = arr2[i];
				}
				return arr3;
			}
			
			public byte[] getMessageHMAC(ArrayList<Object> message) throws Exception {
				byte[] hmac = null;
				//byte[] content = concatenateArrays(message.toString().getBytes(), iv);
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(bos);
				oos.writeObject(message);
				oos.flush();
				byte[] content = bos.toByteArray();
				
				try {		
					Mac mac = Mac.getInstance("HmacSHA256");
					mac.init(integrity_key);
					hmac = mac.doFinal(content);
					//System.out.println("content is " +Arrays.toString(content));
					//System.out.println("hmac(m) is " +Arrays.toString(hmac));
				} catch (Exception e) {
					e.printStackTrace();
				}	
				return hmac;
			}		
	}
