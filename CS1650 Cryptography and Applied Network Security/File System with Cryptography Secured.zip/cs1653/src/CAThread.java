import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;


public class CAThread extends Thread {

	private final Socket socket;
	private final CA ca;
	private byte[] iv;

	public CAThread(Socket sock, CA ca) {
		this.socket = sock;
		this.ca = ca;
	}

	public void run() {

		try {
			final ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
			final ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());

			Envelope resp = null;

			// get CA request from client
			Envelope req = (Envelope) input.readObject();
			System.out.println("Request received: " + req.getMessage());

			resp = new Envelope("Fail");

			if (req.getMessage().equals("POSTG")) {
				File file = new File("CA/CA_G.txt");
				if (!file.exists())
					file.createNewFile();
				FileOutputStream fos = new FileOutputStream(file);

				PublicKey key = (PublicKey) req.getObjContents().get(0);
				byte[] publicKeyBytes = key.getEncoded();
				fos.write(publicKeyBytes);
				fos.close();
				System.err.println("Public key published to CA_G.txt");

				resp = new Envelope("OK");

			} else if (req.getMessage().equals("POSTF")) {

				String name = (String) req.getObjContents().get(0);
				PublicKey key = (PublicKey) req.getObjContents().get(1);

				File file = new File("CA/CA_F.txt");
				if (!file.exists())
					file.createNewFile();
				BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
				bw.write(name + "\n");
				bw.close();

				File file2 = new File("CA/" + name + ".txt");
				if (file2.exists())
					file2.delete();
				file2.createNewFile();

				FileOutputStream fos = new FileOutputStream(file2);

				byte[] publicKeyBytes = key.getEncoded();
				fos.write(publicKeyBytes);
				fos.close();
				System.err.println("Public key published to CA_F.txt");

				resp = new Envelope("OK");

			} else if (req.getMessage().equals("Group Server Public Key")) {
				resp = new Envelope("OK");
				resp.addObject(getGroupServerPublicKeyFromCA());
				System.out.printf("Sending group server's public key to client \n");			
				
			} else if(req.getMessage().equals("setIv")) {
				iv =(byte[]) req.getObjContents().get(0);
				if(iv!= null) {
					resp = new Envelope("OK");
					System.out.printf("Set up iv on CA \n");	
				}
			}
			
			else {

				// check parameters included in request message, 1. FileServerName
				if (checkEnvelopePara(1, req)) {
					// get file server name from request
					String fileServerName = null;
					fileServerName = (String) req.getObjContents().get(0);
					// check if file server name is null
					if (!fileServerName.equals(null)) {
						// check if server name is in CA list
						if (checkIfServerExist(fileServerName)) {
							resp = new Envelope("OK");
							resp.addObject(getPublicKeyFromCA(fileServerName));
							System.out.printf("Sending %s's public key to client \n", fileServerName);
						}
					}
				}

			}

			// send key to client
			output.writeObject(resp);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static boolean checkEnvelopePara(int para_num, Envelope e) {

		// Does envelope provide enough parameters?
		if (e.getObjContents().size() == para_num) {
			for (Object obj : e.getObjContents()) {
				if (obj == null) {
					System.err.println("Some of the parameters are null.");
					return false;
				}
			}

			return true;
		}
		System.err.println("Incorrect number of parameters are provided.");
		return false;
	}

	private boolean checkIfServerExist(String fileServerName) throws IOException {
		File file = new File("CA/CA_F.txt");
		if (!file.exists()) {
			System.out.println("CA.txt, file Not Exist");
			return false;
		} else {
			file.createNewFile();
		}

		BufferedReader br = new BufferedReader(new FileReader(file));
		String line = null;
		boolean exist = false;

		while ((line = br.readLine()) != null) {
			// if finding name is in list
			if (fileServerName.equals(line)) {
				exist = true;
				break;
			}
		}

		System.out.println("get key from " + fileServerName);
		if (!exist) {
			System.err.println("Cannot find key");
		}

		return exist;

	}

	private static Key getPublicKeyFromCA(String fileServerName)
			throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

		Key publicKey = null;
		File f = new File("CA/" + fileServerName + ".txt");

		FileInputStream fis = new FileInputStream(f);
		DataInputStream dis = new DataInputStream(fis);
		byte[] keyBytes = new byte[(int) f.length()];
		dis.readFully(keyBytes);
		dis.close();

		X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance("RSA");
		publicKey = kf.generatePublic(spec);
		return publicKey;
	}
	
	private static Key getGroupServerPublicKeyFromCA()
			throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

		Key publicKey = null;
		File f = new File("CA/CA_G.txt");

		FileInputStream fis = new FileInputStream(f);
		DataInputStream dis = new DataInputStream(fis);
		byte[] keyBytes = new byte[(int) f.length()];
		dis.readFully(keyBytes);
		dis.close();

		X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
		KeyFactory kf = KeyFactory.getInstance("RSA");
		publicKey = kf.generatePublic(spec);
		return publicKey;
	}
}
