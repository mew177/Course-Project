import java.net.Socket;
import java.net.UnknownHostException;

import javax.crypto.SealedObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public abstract class Client {

	/* protected keyword is like private but subclasses have access
	 * Socket and input/output streams
	 */
	protected Socket sock;
	protected ObjectOutputStream output;
	protected ObjectInputStream input;
	private String server;
	private int port;

	
	// Create connection with server
	public boolean connect(final String server, final int port) {
		System.out.println("attempting to connect");
		
		try {
			// making socket connection
			sock = new Socket(server, port);
			System.out.printf("Connected to server %s on port %d \n", server, port);
			
			// socket stream initialization output/ input stream
			output = new ObjectOutputStream(sock.getOutputStream());
			input = new ObjectInputStream(sock.getInputStream());
			
			// return true if client initialization success
			return true;
			
		} catch (UnknownHostException e) {
			System.err.println("Connection Error @Client.java: " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Connection Error @Client.java: " + e.getMessage());
			e.printStackTrace();
		} 
		
		// return false if client initialization fail
		return false;

		/* TODO: Write this method */

	}

	public boolean isConnected() {
		if (sock == null || !sock.isConnected()) {
			return false;
		}
		else {
			return true;
		}
	}
	
	public void disconnect(){
		if (isConnected()) {
			try
			{
				Envelope message = new Envelope("DISCONNECT");
				
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
				e.printStackTrace(System.err);
			}
		}
	}


}
