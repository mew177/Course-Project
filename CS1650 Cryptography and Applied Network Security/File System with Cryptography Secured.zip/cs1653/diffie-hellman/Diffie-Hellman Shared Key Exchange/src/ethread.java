import java.lang.Thread; // We will extend Java's base Thread class
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

import javax.crypto.KeyAgreement;

import java.io.ObjectInputStream; // For reading Java objects off of the wire
import java.io.ObjectOutputStream; // For writing Java objects to the wire

/**
 * A simple server thread. This class just echoes the messages sent over the
 * socket until the socket is closed.
 *
 * @author Adam J. Lee (adamlee@cs.pitt.edu)
 */
public class ethread extends Thread {
	private final Socket socket; // The socket that we'll be talking over

	/**
	 * Constructor that sets up the socket we'll chat over
	 *
	 * @param _socket The socket passed in from the server
	 *
	 */
	public ethread(Socket _socket) {
		socket = _socket;
	}

	/**
	 * run() is basically the main method of a thread. This thread simply reads
	 * Message objects off of the socket.
	 *
	 */
	public void run() {
		try {
			// Print incoming message
			System.out.println("** New connection from " + socket.getInetAddress() + ":" + socket.getPort() + " **");

			// set up I/O streams with the client
			final ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
			final ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());

			// Loop to read messages
			Message msg = null;
			Message resp = null;
			int count = 0;
			do {
				// read and print message
				resp = (Message) input.readObject();
				
				System.out.println("[" + socket.getInetAddress() + ":" + socket.getPort() + "] " + resp.theMessage);

				if (resp.theMessage.equals("DH")) {
					PrivateKey privateKey = null;
					PublicKey publicKey = null;
					PublicKey receivedPublicKey = null;
					byte[] secretKey = null;

					// generate keys
					try {
						final KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("DH");
						keyPairGenerator.initialize(1024);

						final KeyPair keyPair = keyPairGenerator.generateKeyPair();

						privateKey = keyPair.getPrivate();
						publicKey = keyPair.getPublic();
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					System.out.println("generate key done");
					
					// receive public key
					resp = (Message) input.readObject();
					receivedPublicKey = resp.getPublicKey();
					
					System.out.println("receive key done");

					// send public key
					msg = new Message("Public key from Server");
					msg.addPublicKey(publicKey);
					output.writeObject(msg);	
					
					System.out.println("send key done");

					// generate common secret
					try {
						final KeyAgreement keyAgreement = KeyAgreement.getInstance("DH");
						keyAgreement.init(privateKey);
						keyAgreement.doPhase(receivedPublicKey, true);
						
						secretKey = keyAgreement.generateSecret();

						//secretKey = shortenSecretKey(keyAgreement.generateSecret());
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					System.out.println("generate shared key done");
					
					
					System.out.println("secret key:" + Base64.getEncoder().encodeToString(secretKey));		
				}

				// Write an ACK back to the sender
				count++;
				output.writeObject(new Message("Recieved message #" + count));

			} while (!msg.theMessage.toUpperCase().equals("EXIT"));

			// Close and cleanup
			System.out
					.println("** Closing connection with " + socket.getInetAddress() + ":" + socket.getPort() + " **");
			socket.close();

		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}

	} // -- end run()

	private byte[] shortenSecretKey(final byte[] longKey) {

		try {

			// Use 8 bytes (64 bits) for DES, 6 bytes (48 bits) for Blowfish
			final byte[] shortenedKey = new byte[8];

			System.arraycopy(longKey, 0, shortenedKey, 0, shortenedKey.length);

			return shortenedKey;

			// Below lines can be more secure
			// final SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			// final DESKeySpec desSpec = new DESKeySpec(longKey);
			//
			// return keyFactory.generateSecret(desSpec).getEncoded();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
} // -- end class ethread