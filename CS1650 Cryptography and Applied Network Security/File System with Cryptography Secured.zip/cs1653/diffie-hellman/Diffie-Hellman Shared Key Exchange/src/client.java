import java.net.Socket; // Used to connect to the server
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.KeyAgreement;
import javax.crypto.spec.DHParameterSpec;
import javax.crypto.spec.DHPublicKeySpec;

import org.omg.CORBA.SystemException;

import java.io.ObjectInputStream; // Used to read objects sent from the server
import java.io.ObjectOutputStream; // Used to write objects to the server
import java.math.BigInteger;
import java.io.BufferedReader; // Needed to read from the console
import java.io.InputStreamReader; // Needed to read from the console

public class client {
	public static void main(String[] args) {
		// Error checking for arguments
		if (args.length != 1) {
			System.err.println("Not enough arguments.\n");
			System.err.println("Usage:  java EchoClient <Server name or IP>\n");
			System.exit(-1);
		}

		String servername = "127.0.0.1";

		try {
			// Connect to the specified server
			final Socket sock = new Socket(servername, server.SERVER_PORT);
			System.out.println("Connected to " + servername + " on port " + server.SERVER_PORT);

			// Set up I/O streams with the server
			final ObjectOutputStream output = new ObjectOutputStream(sock.getOutputStream());
			final ObjectInputStream input = new ObjectInputStream(sock.getInputStream());

			// loop to send messages
			Message msg = null, resp = null;
			do {
				msg = new Message(readSomeText());
				output.writeObject(msg);
				
				System.out.println(msg.theMessage);

				if (msg.theMessage.equals("DH")) {
					/*
					 *  Start create shared key
					 */
					
					System.out.println("in");
					
					PrivateKey privateKey = null;
				    PublicKey publicKey = null;
				    PublicKey receivedPublicKey = null;
				    byte[] secretKey = null;
				    
				    // generate keys
				    try {
			            final KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("DH");
			            keyPairGenerator.initialize(1024);

			            final KeyPair keyPair = keyPairGenerator.generateKeyPair();

			            privateKey = keyPair.getPrivate();
			            publicKey  = keyPair.getPublic();
			        } catch (Exception e) {
			            e.printStackTrace();
			        }
				    
				    System.out.println("generate key done");
				    
				    // send public key		
				    msg = new Message("public key from client");
				    msg.addPublicKey(publicKey);	
				    output.writeObject(msg);		
				    
				    System.out.println("send key done");
				    
				    // receive public key
				    resp = (Message) input.readObject();
				    receivedPublicKey = resp.getPublicKey();
				    
				    System.out.println("receive key done");
				    
				    // generate common secret
				    try {
			            final KeyAgreement keyAgreement = KeyAgreement.getInstance("DH");
			            keyAgreement.init(privateKey);
			            keyAgreement.doPhase(receivedPublicKey, true);
			            
			            secretKey = keyAgreement.generateSecret();

			            //secretKey = shortenSecretKey(keyAgreement.generateSecret());
			        } catch (Exception e) {
			            e.printStackTrace();
			        }
				    
				    System.out.println("generate shared key done");
				    
				    
				    System.out.println("secret key:" + Base64.getEncoder().encodeToString(secretKey));
				    
				} else {
					resp = (Message) input.readObject();
					System.out.println("\nServer says: " + resp.theMessage + "\n");
				}

			} while (!msg.theMessage.toUpperCase().equals("EXIT"));

			sock.close();

		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace(System.err);
		}

	}

	private static String readSomeText() {
		try {
			System.out.println("Enter a line of text, or type \"EXIT\" to quit.");
			System.out.print(" > ");
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			return in.readLine();
		} catch (Exception e) {
			// Uh oh...
			return "";
		}

	}
	
	public static void createSpecificKey(BigInteger p, BigInteger g) throws Exception {
	    KeyPairGenerator kpg = KeyPairGenerator.getInstance("DiffieHellman");

	    DHParameterSpec param = new DHParameterSpec(p, g);
	    kpg.initialize(param);
	    KeyPair kp = kpg.generateKeyPair();

	    KeyFactory kfactory = KeyFactory.getInstance("DiffieHellman");

	    DHPublicKeySpec kspec = (DHPublicKeySpec) kfactory.getKeySpec(kp.getPublic(),
	        DHPublicKeySpec.class);
	  }
	
	private static byte[] shortenSecretKey(final byte[] longKey) {

        try {

            // Use 8 bytes (64 bits) for DES, 6 bytes (48 bits) for Blowfish
            final byte[] shortenedKey = new byte[8];

            System.arraycopy(longKey, 0, shortenedKey, 0, shortenedKey.length);

            return shortenedKey;

            // Below lines can be more secure
            // final SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            // final DESKeySpec       desSpec    = new DESKeySpec(longKey);
            //
            // return keyFactory.generateSecret(desSpec).getEncoded();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}